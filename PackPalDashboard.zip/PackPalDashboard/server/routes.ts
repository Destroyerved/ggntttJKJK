import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // Get dashboard data for a specific event
  app.get("/api/dashboard/:eventId", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const dashboardData = await storage.getDashboardData(eventId);
      res.json(dashboardData);
    } catch (error) {
      res.status(500).json({ message: "Error fetching dashboard data" });
    }
  });

  // Get all events
  app.get("/api/events", async (req, res) => {
    try {
      const events = await storage.getAllEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Error fetching events" });
    }
  });

  // Get a specific event
  app.get("/api/events/:id", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      res.status(500).json({ message: "Error fetching event" });
    }
  });

  // Get items for an event
  app.get("/api/events/:eventId/items", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const items = await storage.getItemsByEvent(eventId);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Error fetching items" });
    }
  });

  // Get categories for an event
  app.get("/api/events/:eventId/categories", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const categories = await storage.getCategoriesByEvent(eventId);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Error fetching categories" });
    }
  });

  // Get milestones for an event
  app.get("/api/events/:eventId/milestones", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const milestones = await storage.getMilestonesByEvent(eventId);
      res.json(milestones);
    } catch (error) {
      res.status(500).json({ message: "Error fetching milestones" });
    }
  });

  // Get members for an event
  app.get("/api/events/:eventId/members", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const members = await storage.getMembersByEvent(eventId);
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Error fetching members" });
    }
  });

  // Get recent activities for an event
  app.get("/api/events/:eventId/activities", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const activities = await storage.getActivitiesByEvent(eventId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Error fetching activities" });
    }
  });

  // Get all users
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Error fetching users" });
    }
  });

  // Get current logged-in user
  app.get("/api/me", async (req, res) => {
    try {
      // For mock purposes, return the first user as the current user
      const currentUser = await storage.getUserById(1);
      res.json(currentUser);
    } catch (error) {
      res.status(500).json({ message: "Error fetching current user" });
    }
  });

  // Templates API routes
  
  // Get all templates with metadata
  app.get("/api/templates", async (req, res) => {
    try {
      const templatesData = await storage.getTemplatesData();
      res.json(templatesData);
    } catch (error) {
      res.status(500).json({ message: "Error fetching templates data" });
    }
  });

  // Get a specific template
  app.get("/api/templates/:id", async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const template = await storage.getTemplate(templateId);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      // Get categories and items for this template
      const categories = await storage.getTemplateCategories(templateId);
      
      // Get all items for this template
      const items = await storage.getTemplateItems(templateId);
      
      // Format the response to include categories with their items
      const formattedCategories = await Promise.all(categories.map(async (category) => {
        const categoryItems = items.filter(item => item.templateCategoryId === category.id);
        return {
          ...category,
          items: categoryItems
        };
      }));
      
      res.json({
        template,
        categories: formattedCategories
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching template details" });
    }
  });

  // Create an event from a template
  app.post("/api/templates/:id/create-event", async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const eventData = req.body;
      
      // Validate the event data
      const validationResult = z.object({
        name: z.string(),
        description: z.string().optional(),
        location: z.string().optional(),
        startDate: z.string().transform(str => new Date(str)),
        endDate: z.string().optional().transform(str => str ? new Date(str) : undefined),
        createdBy: z.number()
      }).safeParse(eventData);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid event data", 
          errors: validationResult.error.errors 
        });
      }
      
      const event = await storage.createEventFromTemplate(templateId, validationResult.data);
      res.status(201).json(event);
    } catch (error) {
      res.status(500).json({ message: "Error creating event from template" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
