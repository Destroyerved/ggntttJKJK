import { db } from "./db";
import {
  users, events, categories, items, eventMilestones, activities, eventMembers,
  templates, templateCategories, templateItems
} from "@shared/schema";
import { addDays, subDays } from 'date-fns';

async function seedDatabase() {
  console.log("🌱 Starting database seeding process...");
  
  // Check if database already has data
  const existingUsers = await db.select().from(users);
  if (existingUsers.length > 0) {
    console.log("Database already has data, skipping seed process.");
    return;
  }

  console.log("Seeding users...");
  const insertedUsers = await db.insert(users).values([
    {
      username: 'johndoe',
      password: 'password123',
      displayName: 'John Doe',
      email: 'john@example.com',
      avatarUrl: 'https://ui-avatars.com/api/?name=John+Doe&background=0D8ABC&color=fff',
      role: 'owner'
    },
    {
      username: 'janesmith',
      password: 'password123',
      displayName: 'Jane Smith',
      email: 'jane@example.com',
      avatarUrl: 'https://ui-avatars.com/api/?name=Jane+Smith&background=F06292&color=fff',
      role: 'admin'
    },
    {
      username: 'bobwilliams',
      password: 'password123',
      displayName: 'Bob Williams',
      email: 'bob@example.com',
      avatarUrl: 'https://ui-avatars.com/api/?name=Bob+Williams&background=4CAF50&color=fff',
      role: 'member'
    },
    {
      username: 'sarahparker',
      password: 'password123',
      displayName: 'Sarah Parker',
      email: 'sarah@example.com',
      avatarUrl: 'https://ui-avatars.com/api/?name=Sarah+Parker&background=FF9800&color=fff',
      role: 'member'
    }
  ]).returning();

  console.log(`Seeded ${insertedUsers.length} users`);
  
  // Create an event
  console.log("Seeding events...");
  const now = new Date();
  const insertedEvents = await db.insert(events).values([
    {
      name: 'Summer Camping Trip',
      description: 'Annual company retreat in the mountains',
      location: 'Mount Rainier National Park',
      startDate: addDays(now, 30),
      endDate: addDays(now, 35),
      createdBy: insertedUsers[0].id,
      createdAt: now,
      templateId: null
    }
  ]).returning();
  console.log(`Seeded ${insertedEvents.length} events`);
  
  // Create categories for the event
  console.log("Seeding categories...");
  const insertedCategories = await db.insert(categories).values([
    { name: 'Shelter', eventId: insertedEvents[0].id },
    { name: 'Food & Cooking', eventId: insertedEvents[0].id },
    { name: 'Clothing', eventId: insertedEvents[0].id },
    { name: 'Tools & Equipment', eventId: insertedEvents[0].id },
    { name: 'First Aid & Safety', eventId: insertedEvents[0].id }
  ]).returning();
  console.log(`Seeded ${insertedCategories.length} categories`);
  
  // Create items for each category
  console.log("Seeding items...");
  const insertedItems = await db.insert(items).values([
    // Shelter
    {
      name: 'Tent (4-person)',
      description: 'Waterproof dome tent with vestibule',
      categoryId: insertedCategories[0].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[0].id,
      status: 'packed',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 2,
      notes: 'Make sure to bring tent stakes and rainfly'
    },
    {
      name: 'Sleeping bags',
      categoryId: insertedCategories[0].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[1].id,
      status: 'packed',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 8,
      notes: null,
      description: 'Rated for 30°F or below'
    },
    {
      name: 'Camping pillows',
      categoryId: insertedCategories[0].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[2].id,
      status: 'to_pack',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 8,
      notes: null,
      description: null
    },
    
    // Food & Cooking
    {
      name: 'Portable camp stove',
      description: '2-burner propane stove',
      categoryId: insertedCategories[1].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[3].id,
      status: 'to_pack',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 1,
      notes: 'Don\'t forget propane tanks'
    },
    {
      name: 'Cooler',
      description: 'Large cooler for perishable food',
      categoryId: insertedCategories[1].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[0].id,
      status: 'to_pack',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 2,
      notes: 'Pack with ice before departure'
    },
    
    // Clothing
    {
      name: 'Rain jackets',
      categoryId: insertedCategories[2].id,
      eventId: insertedEvents[0].id,
      assignedTo: null,
      status: 'to_pack',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 8,
      notes: 'One per person',
      description: 'Waterproof rain jackets'
    },
    
    // Tools & Equipment
    {
      name: 'Headlamps',
      description: 'Hands-free lighting',
      categoryId: insertedCategories[3].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[1].id,
      status: 'packed',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 8,
      notes: 'Check batteries'
    },
    {
      name: 'Multi-tool',
      description: 'Swiss Army knife or Leatherman',
      categoryId: insertedCategories[3].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[2].id,
      status: 'delivered',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 2,
      notes: null
    },
    
    // First Aid & Safety
    {
      name: 'First aid kit',
      description: 'Complete wilderness first aid kit',
      categoryId: insertedCategories[4].id,
      eventId: insertedEvents[0].id,
      assignedTo: insertedUsers[3].id,
      status: 'packed',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 1,
      notes: 'Check expiration dates on medicines'
    },
    {
      name: 'Sunscreen',
      categoryId: insertedCategories[4].id,
      eventId: insertedEvents[0].id,
      assignedTo: null,
      status: 'to_pack',
      createdBy: insertedUsers[0].id,
      createdAt: now,
      updatedAt: now,
      quantity: 4,
      notes: 'SPF 50+ waterproof',
      description: null
    }
  ]).returning();
  console.log(`Seeded ${insertedItems.length} items`);
  
  // Create milestones for the event
  console.log("Seeding milestones...");
  const insertedMilestones = await db.insert(eventMilestones).values([
    {
      eventId: insertedEvents[0].id,
      name: 'Finalize location details',
      date: subDays(now, 5),
      completed: true
    },
    {
      eventId: insertedEvents[0].id,
      name: 'Send invitations',
      date: subDays(now, 2),
      completed: true
    },
    {
      eventId: insertedEvents[0].id,
      name: 'Confirm attendees',
      date: addDays(now, 7),
      completed: false
    },
    {
      eventId: insertedEvents[0].id,
      name: 'Complete packing',
      date: addDays(now, 25),
      completed: false
    },
    {
      eventId: insertedEvents[0].id,
      name: 'Depart for campsite',
      date: addDays(now, 30),
      completed: false
    }
  ]).returning();
  console.log(`Seeded ${insertedMilestones.length} milestones`);
  
  // Create activities for the event
  console.log("Seeding activities...");
  const insertedActivities = await db.insert(activities).values([
    {
      userId: insertedUsers[0].id,
      eventId: insertedEvents[0].id,
      itemId: insertedItems[0].id,
      action: 'created',
      details: { status: 'to_pack' },
      createdAt: subDays(now, 7)
    },
    {
      userId: insertedUsers[0].id,
      eventId: insertedEvents[0].id,
      itemId: insertedItems[0].id,
      action: 'status_changed',
      details: { from: 'to_pack', to: 'packed' },
      createdAt: subDays(now, 3)
    },
    {
      userId: insertedUsers[1].id,
      eventId: insertedEvents[0].id,
      itemId: insertedItems[6].id,
      action: 'status_changed',
      details: { from: 'to_pack', to: 'packed' },
      createdAt: subDays(now, 2)
    },
    {
      userId: insertedUsers[2].id,
      eventId: insertedEvents[0].id,
      itemId: insertedItems[7].id,
      action: 'status_changed',
      details: { from: 'packed', to: 'delivered' },
      createdAt: subDays(now, 1)
    },
    {
      userId: insertedUsers[3].id,
      eventId: insertedEvents[0].id,
      itemId: insertedItems[8].id,
      action: 'status_changed',
      details: { from: 'to_pack', to: 'packed' },
      createdAt: now
    }
  ]).returning();
  console.log(`Seeded ${insertedActivities.length} activities`);
  
  // Create event members
  console.log("Seeding event members...");
  const insertedEventMembers = await db.insert(eventMembers).values([
    {
      userId: insertedUsers[0].id,
      eventId: insertedEvents[0].id,
      role: 'owner'
    },
    {
      userId: insertedUsers[1].id,
      eventId: insertedEvents[0].id,
      role: 'admin'
    },
    {
      userId: insertedUsers[2].id,
      eventId: insertedEvents[0].id,
      role: 'member'
    },
    {
      userId: insertedUsers[3].id,
      eventId: insertedEvents[0].id,
      role: 'member'
    }
  ]).returning();
  console.log(`Seeded ${insertedEventMembers.length} event members`);
  
  // Create templates
  console.log("Seeding templates...");
  const templateTypes = [
    'Camping', 'Vacation', 'Party', 'Business Trip', 'Conference', 
    'Outdoor Adventure', 'Festival', 'Road Trip', 'Family Reunion'
  ];
  
  // Let's create at least 20 templates as requested
  const templateData = [];
  for (let i = 0; i < 20; i++) {
    const type = templateTypes[i % templateTypes.length];
    const name = `${type} ${i < 9 ? 'Template' : 'Packing List'} ${i + 1}`;
    templateData.push({
      name,
      description: `A complete packing list for your next ${type.toLowerCase()}`,
      type,
      thumbnail: `https://placehold.co/600x400/e2e8f0/1e293b?text=${encodeURIComponent(name)}`,
      isPublic: true,
      createdBy: insertedUsers[i % insertedUsers.length].id,
      createdAt: now
    });
  }
  
  const insertedTemplates = await db.insert(templates).values(templateData).returning();
  console.log(`Seeded ${insertedTemplates.length} templates`);
  
  // Create detailed template categories and items for the camping template
  const campingTemplate = insertedTemplates.find(t => t.type === 'Camping' && t.name.includes('Template 1'));
  
  if (campingTemplate) {
    console.log("Seeding detailed template categories and items...");
    
    // Create template categories
    const campingCategories = await db.insert(templateCategories).values([
      { name: 'Shelter', templateId: campingTemplate.id },
      { name: 'Sleeping', templateId: campingTemplate.id },
      { name: 'Clothing', templateId: campingTemplate.id },
      { name: 'Kitchen', templateId: campingTemplate.id },
      { name: 'Food', templateId: campingTemplate.id },
      { name: 'Personal Items', templateId: campingTemplate.id },
      { name: 'First Aid & Safety', templateId: campingTemplate.id },
      { name: 'Tools & Repairs', templateId: campingTemplate.id },
      { name: 'Navigation & Communication', templateId: campingTemplate.id },
      { name: 'Entertainment', templateId: campingTemplate.id }
    ]).returning();
    
    // Get the IDs for each category by name
    const categoriesMap = new Map(campingCategories.map(cat => [cat.name, cat.id]));
    
    // Create template items
    const templateItemsData = [
      // Shelter
      { name: 'Tent', description: 'With rainfly and footprint', templateCategoryId: categoriesMap.get('Shelter')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Tent stakes', templateCategoryId: categoriesMap.get('Shelter')!, templateId: campingTemplate.id, quantity: 8 },
      { name: 'Tarp or canopy', description: 'For additional shelter', templateCategoryId: categoriesMap.get('Shelter')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Hammock', templateCategoryId: categoriesMap.get('Shelter')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      
      // Sleeping
      { name: 'Sleeping bag', description: 'Appropriate for the temperature', templateCategoryId: categoriesMap.get('Sleeping')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Sleeping pad', description: 'Insulated for ground comfort', templateCategoryId: categoriesMap.get('Sleeping')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Pillow', description: 'Camping pillow or stuff sack', templateCategoryId: categoriesMap.get('Sleeping')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Eye mask', templateCategoryId: categoriesMap.get('Sleeping')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      { name: 'Earplugs', templateCategoryId: categoriesMap.get('Sleeping')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      
      // Clothing
      { name: 'Moisture-wicking t-shirts', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 3 },
      { name: 'Long-sleeve shirts', description: 'For sun and bug protection', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 2 },
      { name: 'Hiking pants/shorts', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 2 },
      { name: 'Underwear', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 3 },
      { name: 'Socks', description: 'Wool or synthetic', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 3 },
      { name: 'Rain jacket/poncho', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Warm layer/fleece', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Hiking boots/shoes', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Camp shoes/sandals', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Hat', description: 'For sun protection', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Beanie', description: 'For cold evenings', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Gloves', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1, notes: 'If cold weather expected' },
      { name: 'Swimsuit', templateCategoryId: categoriesMap.get('Clothing')!, templateId: campingTemplate.id, quantity: 1, notes: 'If swimming planned' },
      
      // Kitchen
      { name: 'Stove', description: 'With fuel', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Cookpot', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Frying pan', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      { name: 'Plates/bowls', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Utensils', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Cup/mug', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Water bottles/hydration system', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Water filter/purifier', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Biodegradable soap', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Dish towel/scrubber', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Trash bags', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 2 },
      { name: 'Cooler', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1, notes: 'If bringing perishable food' },
      { name: 'Can opener', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Coffee maker', description: 'French press or pour-over', templateCategoryId: categoriesMap.get('Kitchen')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      
      // Food (simplified list)
      { name: 'Breakfast items', description: 'Oatmeal, granola, etc.', templateCategoryId: categoriesMap.get('Food')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Lunch items', description: 'Bread, wraps, etc.', templateCategoryId: categoriesMap.get('Food')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Dinner items', description: 'Pasta, rice, etc.', templateCategoryId: categoriesMap.get('Food')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Snacks', description: 'Trail mix, energy bars, etc.', templateCategoryId: categoriesMap.get('Food')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Beverages', description: 'Coffee, tea, etc.', templateCategoryId: categoriesMap.get('Food')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Seasonings', description: 'Salt, pepper, spices', templateCategoryId: categoriesMap.get('Food')!, templateId: campingTemplate.id, quantity: 1 },
      
      // Personal Items
      { name: 'Toothbrush & toothpaste', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Soap/shower gel', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Towel', description: 'Quick-dry', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Toilet paper', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Hand sanitizer', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Insect repellent', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Sunscreen', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Lip balm', description: 'With SPF', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Medications', templateCategoryId: categoriesMap.get('Personal Items')!, templateId: campingTemplate.id, quantity: 1 },
      
      // First Aid & Safety
      { name: 'First aid kit', templateCategoryId: categoriesMap.get('First Aid & Safety')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Whistle', templateCategoryId: categoriesMap.get('First Aid & Safety')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Fire starter', templateCategoryId: categoriesMap.get('First Aid & Safety')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Matches/lighter', templateCategoryId: categoriesMap.get('First Aid & Safety')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Emergency blanket', templateCategoryId: categoriesMap.get('First Aid & Safety')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Bear spray', templateCategoryId: categoriesMap.get('First Aid & Safety')!, templateId: campingTemplate.id, quantity: 1, notes: 'If in bear country' },
      
      // Tools & Repairs
      { name: 'Multi-tool', templateCategoryId: categoriesMap.get('Tools & Repairs')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Duct tape', templateCategoryId: categoriesMap.get('Tools & Repairs')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Paracord', description: '50 feet', templateCategoryId: categoriesMap.get('Tools & Repairs')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Tent repair kit', templateCategoryId: categoriesMap.get('Tools & Repairs')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Sewing kit', templateCategoryId: categoriesMap.get('Tools & Repairs')!, templateId: campingTemplate.id, quantity: 1, notes: 'Small' },
      
      // Navigation & Communication
      { name: 'Map & compass', templateCategoryId: categoriesMap.get('Navigation & Communication')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'GPS device', templateCategoryId: categoriesMap.get('Navigation & Communication')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      { name: 'Headlamp/flashlight', description: 'With extra batteries', templateCategoryId: categoriesMap.get('Navigation & Communication')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Phone', templateCategoryId: categoriesMap.get('Navigation & Communication')!, templateId: campingTemplate.id, quantity: 1 },
      { name: 'Portable charger', templateCategoryId: categoriesMap.get('Navigation & Communication')!, templateId: campingTemplate.id, quantity: 1 },
      
      // Entertainment
      { name: 'Book/e-reader', templateCategoryId: categoriesMap.get('Entertainment')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      { name: 'Journal & pen', templateCategoryId: categoriesMap.get('Entertainment')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      { name: 'Camera', templateCategoryId: categoriesMap.get('Entertainment')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      { name: 'Binoculars', templateCategoryId: categoriesMap.get('Entertainment')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' },
      { name: 'Cards/games', templateCategoryId: categoriesMap.get('Entertainment')!, templateId: campingTemplate.id, quantity: 1, notes: 'Optional' }
    ];
    
    const insertedTemplateItems = await db.insert(templateItems).values(templateItemsData).returning();
    console.log(`Seeded ${campingCategories.length} template categories and ${insertedTemplateItems.length} template items`);
  }
  
  // Create a few more detailed templates
  const vacationTemplate = insertedTemplates.find(t => t.type === 'Vacation' && t.name.includes('Template 2'));
  if (vacationTemplate) {
    const vacationCategories = await db.insert(templateCategories).values([
      { name: 'Documents', templateId: vacationTemplate.id },
      { name: 'Clothing', templateId: vacationTemplate.id },
      { name: 'Toiletries', templateId: vacationTemplate.id },
      { name: 'Electronics', templateId: vacationTemplate.id },
      { name: 'Beach Gear', templateId: vacationTemplate.id },
      { name: 'Medications', templateId: vacationTemplate.id },
    ]).returning();
    
    // Map of category names to IDs
    const vacCategoriesMap = new Map(vacationCategories.map(cat => [cat.name, cat.id]));
    
    // Vacation template items (just a sampling)
    await db.insert(templateItems).values([
      // Documents
      { name: 'Passport', templateCategoryId: vacCategoriesMap.get('Documents')!, templateId: vacationTemplate.id, quantity: 1 },
      { name: 'Flight tickets', templateCategoryId: vacCategoriesMap.get('Documents')!, templateId: vacationTemplate.id, quantity: 1 },
      { name: 'Hotel reservations', templateCategoryId: vacCategoriesMap.get('Documents')!, templateId: vacationTemplate.id, quantity: 1 },
      
      // Clothing - just a few examples
      { name: 'T-shirts', templateCategoryId: vacCategoriesMap.get('Clothing')!, templateId: vacationTemplate.id, quantity: 5 },
      { name: 'Shorts', templateCategoryId: vacCategoriesMap.get('Clothing')!, templateId: vacationTemplate.id, quantity: 3 },
      { name: 'Swimsuit', templateCategoryId: vacCategoriesMap.get('Clothing')!, templateId: vacationTemplate.id, quantity: 2 },
      
      // Electronics
      { name: 'Phone charger', templateCategoryId: vacCategoriesMap.get('Electronics')!, templateId: vacationTemplate.id, quantity: 1 },
      { name: 'Camera', templateCategoryId: vacCategoriesMap.get('Electronics')!, templateId: vacationTemplate.id, quantity: 1 },
      { name: 'Adapter plugs', templateCategoryId: vacCategoriesMap.get('Electronics')!, templateId: vacationTemplate.id, quantity: 2 },
      
      // Beach Gear
      { name: 'Beach towel', templateCategoryId: vacCategoriesMap.get('Beach Gear')!, templateId: vacationTemplate.id, quantity: 1 },
      { name: 'Sunscreen', templateCategoryId: vacCategoriesMap.get('Beach Gear')!, templateId: vacationTemplate.id, quantity: 1 },
      { name: 'Beach bag', templateCategoryId: vacCategoriesMap.get('Beach Gear')!, templateId: vacationTemplate.id, quantity: 1 }
    ]);
  }
  
  const partyTemplate = insertedTemplates.find(t => t.type === 'Party' && t.name.includes('Template 3'));
  if (partyTemplate) {
    const partyCategories = await db.insert(templateCategories).values([
      { name: 'Decorations', templateId: partyTemplate.id },
      { name: 'Food', templateId: partyTemplate.id },
      { name: 'Drinks', templateId: partyTemplate.id },
      { name: 'Entertainment', templateId: partyTemplate.id },
      { name: 'Tableware', templateId: partyTemplate.id }
    ]).returning();
    
    // Map of category names to IDs
    const partyCategoriesMap = new Map(partyCategories.map(cat => [cat.name, cat.id]));
    
    // Party template items (just a sampling)
    await db.insert(templateItems).values([
      // Decorations
      { name: 'Balloons', templateCategoryId: partyCategoriesMap.get('Decorations')!, templateId: partyTemplate.id, quantity: 20 },
      { name: 'Streamers', templateCategoryId: partyCategoriesMap.get('Decorations')!, templateId: partyTemplate.id, quantity: 5 },
      { name: 'Party banner', templateCategoryId: partyCategoriesMap.get('Decorations')!, templateId: partyTemplate.id, quantity: 1 },
      
      // Food
      { name: 'Finger foods', templateCategoryId: partyCategoriesMap.get('Food')!, templateId: partyTemplate.id, quantity: 1, notes: 'Assorted' },
      { name: 'Chips and dip', templateCategoryId: partyCategoriesMap.get('Food')!, templateId: partyTemplate.id, quantity: 3 },
      { name: 'Cake', templateCategoryId: partyCategoriesMap.get('Food')!, templateId: partyTemplate.id, quantity: 1 },
      
      // Drinks
      { name: 'Soda', templateCategoryId: partyCategoriesMap.get('Drinks')!, templateId: partyTemplate.id, quantity: 4, notes: 'Assorted 2-liter bottles' },
      { name: 'Juice', templateCategoryId: partyCategoriesMap.get('Drinks')!, templateId: partyTemplate.id, quantity: 2 },
      { name: 'Ice', templateCategoryId: partyCategoriesMap.get('Drinks')!, templateId: partyTemplate.id, quantity: 2, notes: 'Bags' },
      
      // Tableware
      { name: 'Paper plates', templateCategoryId: partyCategoriesMap.get('Tableware')!, templateId: partyTemplate.id, quantity: 1, notes: 'Pack of 50' },
      { name: 'Plastic cups', templateCategoryId: partyCategoriesMap.get('Tableware')!, templateId: partyTemplate.id, quantity: 1, notes: 'Pack of 50' },
      { name: 'Napkins', templateCategoryId: partyCategoriesMap.get('Tableware')!, templateId: partyTemplate.id, quantity: 1, notes: 'Pack of 100' }
    ]);
  }
  
  console.log("✅ Database seeding complete!");
}

export { seedDatabase };