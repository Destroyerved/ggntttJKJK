import {
  User, Event, EventMilestone, Category, Item, Activity, EventMember,
  Template, TemplateCategory, TemplateItem,
  InsertUser, InsertEvent, InsertEventMilestone, InsertCategory, InsertItem, InsertActivity, InsertEventMember,
  InsertTemplate, InsertTemplateCategory, InsertTemplateItem,
  users, events, eventMilestones, categories, items, activities, eventMembers,
  templates, templateCategories, templateItems
} from "@shared/schema";
import { IStorage } from "./storage";
import { db } from "./db";
import { and, asc, desc, eq, isNull } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUserById(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  // Event operations
  async getEvent(id: number): Promise<Event | undefined> {
    const result = await db.select().from(events).where(eq(events.id, id));
    return result[0];
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const result = await db.insert(events).values({
      ...event,
      createdAt: new Date()
    }).returning();
    return result[0];
  }

  async getAllEvents(): Promise<Event[]> {
    return db.select().from(events);
  }

  // Item operations
  async getItem(id: number): Promise<Item | undefined> {
    const result = await db.select().from(items).where(eq(items.id, id));
    return result[0];
  }

  async createItem(item: InsertItem): Promise<Item> {
    const result = await db.insert(items).values({
      ...item,
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    return result[0];
  }

  async updateItem(id: number, updateData: Partial<InsertItem>): Promise<Item | undefined> {
    const result = await db.update(items)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(items.id, id))
      .returning();
    return result[0];
  }

  async getItemsByEvent(eventId: number): Promise<Item[]> {
    return db.select()
      .from(items)
      .where(eq(items.eventId, eventId));
  }

  // Category operations
  async getCategory(id: number): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.id, id));
    return result[0];
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const result = await db.insert(categories).values(category).returning();
    return result[0];
  }

  async getCategoriesByEvent(eventId: number): Promise<Category[]> {
    return db.select()
      .from(categories)
      .where(eq(categories.eventId, eventId));
  }

  // Event Milestone operations
  async getMilestone(id: number): Promise<EventMilestone | undefined> {
    const result = await db.select().from(eventMilestones).where(eq(eventMilestones.id, id));
    return result[0];
  }

  async createMilestone(milestone: InsertEventMilestone): Promise<EventMilestone> {
    const result = await db.insert(eventMilestones).values(milestone).returning();
    return result[0];
  }

  async getMilestonesByEvent(eventId: number): Promise<EventMilestone[]> {
    return db.select()
      .from(eventMilestones)
      .where(eq(eventMilestones.eventId, eventId))
      .orderBy(asc(eventMilestones.date));
  }

  // Activity operations
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const result = await db.insert(activities).values({
      ...activity,
      createdAt: new Date()
    }).returning();
    return result[0];
  }

  async getActivitiesByEvent(eventId: number, limit: number = 5): Promise<Activity[]> {
    return db.select()
      .from(activities)
      .where(eq(activities.eventId, eventId))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }

  // EventMember operations
  async createEventMember(eventMember: InsertEventMember): Promise<EventMember> {
    const result = await db.insert(eventMembers).values(eventMember).returning();
    return result[0];
  }

  async getMembersByEvent(eventId: number): Promise<(EventMember & { user: User })[]> {
    const members = await db.select()
      .from(eventMembers)
      .where(eq(eventMembers.eventId, eventId));
    
    const result: (EventMember & { user: User })[] = [];
    
    for (const member of members) {
      const user = await this.getUserById(member.userId);
      if (user) {
        result.push({ ...member, user });
      }
    }
    
    return result;
  }

  // Template operations
  async getTemplate(id: number): Promise<Template | undefined> {
    const result = await db.select().from(templates).where(eq(templates.id, id));
    return result[0];
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const result = await db.insert(templates).values({
      ...template,
      createdAt: new Date()
    }).returning();
    return result[0];
  }

  async getAllTemplates(): Promise<Template[]> {
    return db.select().from(templates);
  }

  async getTemplateCategories(templateId: number): Promise<TemplateCategory[]> {
    return db.select()
      .from(templateCategories)
      .where(eq(templateCategories.templateId, templateId));
  }

  async getTemplateItems(templateId: number): Promise<TemplateItem[]> {
    return db.select()
      .from(templateItems)
      .where(eq(templateItems.templateId, templateId));
  }

  async getTemplateItemsByCategory(templateCategoryId: number): Promise<TemplateItem[]> {
    return db.select()
      .from(templateItems)
      .where(eq(templateItems.templateCategoryId, templateCategoryId));
  }

  async createTemplateCategory(category: InsertTemplateCategory): Promise<TemplateCategory> {
    const result = await db.insert(templateCategories).values(category).returning();
    return result[0];
  }

  async createTemplateItem(item: InsertTemplateItem): Promise<TemplateItem> {
    const result = await db.insert(templateItems).values(item).returning();
    return result[0];
  }

  async createEventFromTemplate(templateId: number, eventData: Partial<InsertEvent>): Promise<Event> {
    const template = await this.getTemplate(templateId);
    if (!template) {
      throw new Error(`Template not found: ${templateId}`);
    }

    // Create new event from template and event data
    const event = await this.createEvent({
      name: eventData.name || template.name,
      description: eventData.description || template.description,
      location: eventData.location || '',
      startDate: eventData.startDate || new Date(),
      endDate: eventData.endDate || null,
      createdBy: eventData.createdBy || template.createdBy,
      templateId: template.id
    });

    // Get template categories
    const templateCategories = await this.getTemplateCategories(templateId);
    
    // Create event categories
    const categoryMap = new Map<number, number>(); // Map template category ID to event category ID
    for (const templateCategory of templateCategories) {
      const category = await this.createCategory({
        name: templateCategory.name,
        eventId: event.id
      });
      categoryMap.set(templateCategory.id, category.id);
    }

    // Get template items
    const templateItems = await this.getTemplateItems(templateId);
    
    // Create event items
    for (const templateItem of templateItems) {
      const categoryId = categoryMap.get(templateItem.templateCategoryId);
      if (!categoryId) continue;
      
      await this.createItem({
        name: templateItem.name,
        description: templateItem.description,
        categoryId,
        eventId: event.id,
        status: 'to_pack',
        createdBy: event.createdBy,
        quantity: templateItem.quantity,
        notes: templateItem.notes
      });
    }

    return event;
  }

  // Dashboard Data
  async getTemplatesData(): Promise<any> {
    const allTemplates = await this.getAllTemplates();
    
    // Enrich templates with category and item counts
    const enrichedTemplates = await Promise.all(allTemplates.map(async template => {
      const categories = await this.getTemplateCategories(template.id);
      const items = await this.getTemplateItems(template.id);
      
      return {
        ...template,
        categoryCount: categories.length,
        itemCount: items.length,
        thumbnail: template.thumbnail || `https://placehold.co/600x400/e2e8f0/1e293b?text=${encodeURIComponent(template.name)}`
      };
    }));
    
    // Get template types with counts
    const uniqueTypes = Array.from(new Set(allTemplates.map(t => t.type)));
    const typeCounts = uniqueTypes.map(type => ({
      type,
      count: allTemplates.filter(t => t.type === type).length
    }));
    
    return {
      templates: enrichedTemplates,
      types: typeCounts,
      totalCount: allTemplates.length
    };
  }

  async getDashboardData(eventId: number): Promise<any> {
    const event = await this.getEvent(eventId);
    if (!event) throw new Error(`Event not found: ${eventId}`);
    
    const categories = await this.getCategoriesByEvent(eventId);
    const items = await this.getItemsByEvent(eventId);
    const milestones = await this.getMilestonesByEvent(eventId);
    const members = await this.getMembersByEvent(eventId);
    const activities = await this.getActivitiesByEvent(eventId, 5);
    
    // Calculate stats
    const totalItems = items.length;
    const toPackItems = items.filter(item => item.status === 'to_pack').length;
    const packedItems = items.filter(item => item.status === 'packed').length;
    const deliveredItems = items.filter(item => item.status === 'delivered').length;
    
    // Calculate progress by category
    const categoryProgress = await Promise.all(categories.map(async category => {
      const categoryItems = items.filter(item => item.categoryId === category.id);
      const totalCategoryItems = categoryItems.length;
      const packedOrDeliveredItems = categoryItems.filter(item => 
        item.status === 'packed' || item.status === 'delivered'
      ).length;
      
      return {
        id: category.id,
        name: category.name,
        total: totalCategoryItems,
        completed: packedOrDeliveredItems,
        percentage: totalCategoryItems > 0 
          ? Math.round((packedOrDeliveredItems / totalCategoryItems) * 100) 
          : 0
      };
    }));
    
    // Enrich activities with user data
    const enrichedActivities = await Promise.all(activities.map(async activity => {
      const user = await this.getUserById(activity.userId);
      return {
        ...activity,
        user
      };
    }));
    
    // Calculate days remaining until event
    const today = new Date();
    const startDate = new Date(event.startDate);
    const daysRemaining = Math.max(0, Math.ceil((startDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
    
    // Calculate overall progress
    const overallProgress = totalItems > 0 
      ? Math.round(((packedItems + deliveredItems) / totalItems) * 100) 
      : 0;
    
    // Sort milestones by date
    const sortedMilestones = [...milestones].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    // Find the next milestone
    const nextMilestone = sortedMilestones.find(m => 
      !m.completed && new Date(m.date) > today
    );
    
    return {
      event,
      stats: {
        totalItems,
        toPackItems,
        packedItems,
        deliveredItems
      },
      categoryProgress,
      members,
      activities: enrichedActivities,
      timeline: {
        daysRemaining,
        progress: overallProgress,
        milestones: sortedMilestones,
        nextMilestone
      }
    };
  }
}