import {
  User, Event, EventMilestone, Category, Item, Activity, EventMember,
  Template, TemplateCategory, TemplateItem,
  InsertUser, InsertEvent, InsertEventMilestone, InsertCategory, InsertItem, InsertActivity, InsertEventMember,
  InsertTemplate, InsertTemplateCategory, InsertTemplateItem
} from "@shared/schema";
import { addDays, subDays, formatISO } from 'date-fns';
import { DatabaseStorage } from './storage.database';

// Define the interface with all required CRUD operations
export interface IStorage {
  // User operations
  getUserById(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Event operations
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  getAllEvents(): Promise<Event[]>;
  
  // Item operations
  getItem(id: number): Promise<Item | undefined>;
  createItem(item: InsertItem): Promise<Item>;
  updateItem(id: number, item: Partial<InsertItem>): Promise<Item | undefined>;
  getItemsByEvent(eventId: number): Promise<Item[]>;
  
  // Category operations
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  getCategoriesByEvent(eventId: number): Promise<Category[]>;
  
  // Event Milestone operations
  getMilestone(id: number): Promise<EventMilestone | undefined>;
  createMilestone(milestone: InsertEventMilestone): Promise<EventMilestone>;
  getMilestonesByEvent(eventId: number): Promise<EventMilestone[]>;
  
  // Activity operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivitiesByEvent(eventId: number, limit?: number): Promise<Activity[]>;
  
  // EventMember operations
  createEventMember(eventMember: InsertEventMember): Promise<EventMember>;
  getMembersByEvent(eventId: number): Promise<(EventMember & { user: User })[]>;
  
  // Template operations
  getTemplate(id: number): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  getAllTemplates(): Promise<Template[]>;
  getTemplateCategories(templateId: number): Promise<TemplateCategory[]>;
  getTemplateItems(templateId: number): Promise<TemplateItem[]>;
  getTemplateItemsByCategory(templateCategoryId: number): Promise<TemplateItem[]>;
  createTemplateCategory(category: InsertTemplateCategory): Promise<TemplateCategory>;
  createTemplateItem(item: InsertTemplateItem): Promise<TemplateItem>;
  createEventFromTemplate(templateId: number, eventData: Partial<InsertEvent>): Promise<Event>;
  
  // Dashboard Data
  getDashboardData(eventId: number): Promise<any>;
  getTemplatesData(): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private events: Map<number, Event>;
  private eventMilestones: Map<number, EventMilestone>;
  private categories: Map<number, Category>;
  private items: Map<number, Item>;
  private activities: Map<number, Activity>;
  private eventMembers: Map<number, EventMember>;
  private templates: Map<number, Template>;
  private templateCategories: Map<number, TemplateCategory>;
  private templateItems: Map<number, TemplateItem>;
  
  private userIdCounter: number;
  private eventIdCounter: number;
  private eventMilestoneIdCounter: number;
  private categoryIdCounter: number;
  private itemIdCounter: number;
  private activityIdCounter: number;
  private eventMemberIdCounter: number;
  private templateIdCounter: number;
  private templateCategoryIdCounter: number;
  private templateItemIdCounter: number;

  constructor() {
    this.users = new Map();
    this.events = new Map();
    this.eventMilestones = new Map();
    this.categories = new Map();
    this.items = new Map();
    this.activities = new Map();
    this.eventMembers = new Map();
    this.templates = new Map();
    this.templateCategories = new Map();
    this.templateItems = new Map();
    
    this.userIdCounter = 1;
    this.eventIdCounter = 1;
    this.eventMilestoneIdCounter = 1;
    this.categoryIdCounter = 1;
    this.itemIdCounter = 1;
    this.activityIdCounter = 1;
    this.eventMemberIdCounter = 1;
    this.templateIdCounter = 1;
    this.templateCategoryIdCounter = 1;
    this.templateItemIdCounter = 1;
    
    // Seed initial data
    this.seedInitialData();
  }

  // User operations
  async getUserById(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      id, 
      ...insertUser,
      avatarUrl: insertUser.avatarUrl || null,
      role: insertUser.role || "member"
    };
    this.users.set(id, user);
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Event operations
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const event: Event = { 
      id, 
      name: insertEvent.name,
      description: insertEvent.description || null,
      location: insertEvent.location || null,
      startDate: insertEvent.startDate,
      endDate: insertEvent.endDate || null,
      createdBy: insertEvent.createdBy,
      createdAt: new Date(),
      templateId: insertEvent.templateId || null
    };
    this.events.set(id, event);
    return event;
  }
  
  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }

  // Item operations
  async getItem(id: number): Promise<Item | undefined> {
    return this.items.get(id);
  }

  async createItem(insertItem: InsertItem): Promise<Item> {
    const id = this.itemIdCounter++;
    const item: Item = { 
      id, 
      name: insertItem.name,
      description: insertItem.description || null,
      categoryId: insertItem.categoryId,
      eventId: insertItem.eventId,
      assignedTo: insertItem.assignedTo || null,
      status: insertItem.status || "to_pack",
      createdBy: insertItem.createdBy,
      createdAt: new Date(),
      updatedAt: new Date(),
      quantity: insertItem.quantity || 1,
      notes: insertItem.notes || null
    };
    this.items.set(id, item);
    return item;
  }

  async updateItem(id: number, updateData: Partial<InsertItem>): Promise<Item | undefined> {
    const item = this.items.get(id);
    if (!item) return undefined;
    
    const updatedItem: Item = { 
      ...item, 
      ...updateData,
      description: updateData.description ?? item.description,
      assignedTo: updateData.assignedTo ?? item.assignedTo,
      status: updateData.status ?? item.status,
      quantity: updateData.quantity ?? item.quantity,
      notes: updateData.notes ?? item.notes,
      updatedAt: new Date()
    };
    
    this.items.set(id, updatedItem);
    return updatedItem;
  }

  async getItemsByEvent(eventId: number): Promise<Item[]> {
    return Array.from(this.items.values()).filter(
      (item) => item.eventId === eventId
    );
  }

  // Category operations
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { id, ...insertCategory };
    this.categories.set(id, category);
    return category;
  }

  async getCategoriesByEvent(eventId: number): Promise<Category[]> {
    return Array.from(this.categories.values()).filter(
      (category) => category.eventId === eventId
    );
  }

  // Event Milestone operations
  async getMilestone(id: number): Promise<EventMilestone | undefined> {
    return this.eventMilestones.get(id);
  }

  async createMilestone(insertMilestone: InsertEventMilestone): Promise<EventMilestone> {
    const id = this.eventMilestoneIdCounter++;
    const milestone: EventMilestone = { 
      id, 
      eventId: insertMilestone.eventId,
      name: insertMilestone.name,
      date: insertMilestone.date,
      completed: insertMilestone.completed || false
    };
    this.eventMilestones.set(id, milestone);
    return milestone;
  }

  async getMilestonesByEvent(eventId: number): Promise<EventMilestone[]> {
    return Array.from(this.eventMilestones.values()).filter(
      (milestone) => milestone.eventId === eventId
    );
  }

  // Activity operations
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const activity: Activity = { 
      id, 
      userId: insertActivity.userId,
      eventId: insertActivity.eventId,
      itemId: insertActivity.itemId || null,
      action: insertActivity.action,
      details: insertActivity.details || {},
      createdAt: new Date()
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getActivitiesByEvent(eventId: number, limit: number = 5): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .filter(activity => activity.eventId === eventId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return activities.slice(0, limit);
  }

  // EventMember operations
  async createEventMember(insertEventMember: InsertEventMember): Promise<EventMember> {
    const id = this.eventMemberIdCounter++;
    const eventMember: EventMember = { 
      id, 
      userId: insertEventMember.userId,
      eventId: insertEventMember.eventId,
      role: insertEventMember.role || "member"
    };
    this.eventMembers.set(id, eventMember);
    return eventMember;
  }

  async getMembersByEvent(eventId: number): Promise<(EventMember & { user: User })[]> {
    const members = Array.from(this.eventMembers.values()).filter(
      (member) => member.eventId === eventId
    );
    
    return members.map(member => {
      const user = this.users.get(member.userId);
      if (!user) throw new Error(`User not found for member: ${member.id}`);
      return { ...member, user };
    });
  }

  // Template operations
  async getTemplate(id: number): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const id = this.templateIdCounter++;
    const template: Template = { 
      id, 
      name: insertTemplate.name,
      type: insertTemplate.type,
      description: insertTemplate.description || null,
      thumbnail: insertTemplate.thumbnail || null,
      isPublic: insertTemplate.isPublic !== undefined ? insertTemplate.isPublic : true,
      createdBy: insertTemplate.createdBy,
      createdAt: new Date() 
    };
    this.templates.set(id, template);
    return template;
  }

  async getAllTemplates(): Promise<Template[]> {
    return Array.from(this.templates.values());
  }

  async getTemplateCategories(templateId: number): Promise<TemplateCategory[]> {
    return Array.from(this.templateCategories.values()).filter(
      (category) => category.templateId === templateId
    );
  }

  async getTemplateItems(templateId: number): Promise<TemplateItem[]> {
    return Array.from(this.templateItems.values()).filter(
      (item) => item.templateId === templateId
    );
  }

  async getTemplateItemsByCategory(templateCategoryId: number): Promise<TemplateItem[]> {
    return Array.from(this.templateItems.values()).filter(
      (item) => item.templateCategoryId === templateCategoryId
    );
  }

  async createTemplateCategory(insertCategory: InsertTemplateCategory): Promise<TemplateCategory> {
    const id = this.templateCategoryIdCounter++;
    const category: TemplateCategory = { id, ...insertCategory };
    this.templateCategories.set(id, category);
    return category;
  }

  async createTemplateItem(insertItem: InsertTemplateItem): Promise<TemplateItem> {
    const id = this.templateItemIdCounter++;
    const item: TemplateItem = { 
      id, 
      name: insertItem.name,
      templateId: insertItem.templateId,
      templateCategoryId: insertItem.templateCategoryId,
      description: insertItem.description || null,
      quantity: insertItem.quantity || 1,
      notes: insertItem.notes || null
    };
    this.templateItems.set(id, item);
    return item;
  }

  async createEventFromTemplate(templateId: number, eventData: Partial<InsertEvent>): Promise<Event> {
    const template = await this.getTemplate(templateId);
    if (!template) {
      throw new Error(`Template not found: ${templateId}`);
    }

    // Create new event from template and event data
    const event = await this.createEvent({
      name: eventData.name || template.name,
      description: eventData.description || template.description,
      location: eventData.location || '',
      startDate: eventData.startDate || new Date(),
      endDate: eventData.endDate || null,
      createdBy: eventData.createdBy || template.createdBy,
      templateId: template.id
    });

    // Get template categories
    const templateCategories = await this.getTemplateCategories(templateId);
    
    // Create event categories
    const categoryMap = new Map<number, number>(); // Map template category ID to event category ID
    for (const templateCategory of templateCategories) {
      const category = await this.createCategory({
        name: templateCategory.name,
        eventId: event.id
      });
      categoryMap.set(templateCategory.id, category.id);
    }

    // Get template items
    const templateItems = await this.getTemplateItems(templateId);
    
    // Create event items
    for (const templateItem of templateItems) {
      const categoryId = categoryMap.get(templateItem.templateCategoryId);
      if (!categoryId) continue;
      
      await this.createItem({
        name: templateItem.name,
        description: templateItem.description,
        categoryId,
        eventId: event.id,
        status: 'to_pack',
        createdBy: event.createdBy,
        quantity: templateItem.quantity,
        notes: templateItem.notes
      });
    }

    return event;
  }

  async getTemplatesData(): Promise<any> {
    const templates = await this.getAllTemplates();
    
    // Enrich templates with category and item counts
    const enrichedTemplates = await Promise.all(templates.map(async template => {
      const categories = await this.getTemplateCategories(template.id);
      const items = await this.getTemplateItems(template.id);
      
      return {
        ...template,
        categoryCount: categories.length,
        itemCount: items.length,
        thumbnail: template.thumbnail || `https://placehold.co/600x400/e2e8f0/1e293b?text=${encodeURIComponent(template.name)}`
      };
    }));
    
    // Get template types with counts
    const types = Array.from(new Set(templates.map(t => t.type)));
    const typeCounts = types.map(type => ({
      type,
      count: templates.filter(t => t.type === type).length
    }));
    
    return {
      templates: enrichedTemplates,
      types: typeCounts,
      totalCount: templates.length
    };
  }

  // Dashboard Data
  async getDashboardData(eventId: number): Promise<any> {
    const event = await this.getEvent(eventId);
    if (!event) throw new Error(`Event not found: ${eventId}`);
    
    const categories = await this.getCategoriesByEvent(eventId);
    const items = await this.getItemsByEvent(eventId);
    const milestones = await this.getMilestonesByEvent(eventId);
    const members = await this.getMembersByEvent(eventId);
    const activities = await this.getActivitiesByEvent(eventId, 5);
    
    // Calculate stats
    const totalItems = items.length;
    const toPackItems = items.filter(item => item.status === 'to_pack').length;
    const packedItems = items.filter(item => item.status === 'packed').length;
    const deliveredItems = items.filter(item => item.status === 'delivered').length;
    
    // Calculate progress by category
    const categoryProgress = categories.map(category => {
      const categoryItems = items.filter(item => item.categoryId === category.id);
      const totalCategoryItems = categoryItems.length;
      const packedOrDeliveredItems = categoryItems.filter(item => 
        item.status === 'packed' || item.status === 'delivered'
      ).length;
      
      return {
        id: category.id,
        name: category.name,
        total: totalCategoryItems,
        completed: packedOrDeliveredItems,
        percentage: totalCategoryItems > 0 
          ? Math.round((packedOrDeliveredItems / totalCategoryItems) * 100) 
          : 0
      };
    });
    
    // Enrich activities with user data
    const enrichedActivities = await Promise.all(activities.map(async activity => {
      const user = await this.getUserById(activity.userId);
      return {
        ...activity,
        user
      };
    }));
    
    // Calculate days remaining until event
    const today = new Date();
    const startDate = new Date(event.startDate);
    const daysRemaining = Math.max(0, Math.ceil((startDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
    
    // Calculate overall progress
    const overallProgress = totalItems > 0 
      ? Math.round(((packedItems + deliveredItems) / totalItems) * 100) 
      : 0;
    
    // Sort milestones by date
    const sortedMilestones = [...milestones].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    // Find the next milestone
    const nextMilestone = sortedMilestones.find(m => 
      !m.completed && new Date(m.date) > today
    );
    
    return {
      event,
      stats: {
        totalItems,
        toPackItems,
        packedItems,
        deliveredItems
      },
      categoryProgress,
      members,
      activities: enrichedActivities,
      timeline: {
        daysRemaining,
        progress: overallProgress,
        milestones: sortedMilestones,
        nextMilestone
      }
    };
  }

  // Seed initial mock data
  private seedInitialData() {
    // Create users
    const user1 = this.createUser({
      username: "alex_johnson",
      password: "password123",
      displayName: "Alex Johnson",
      email: "alex@example.com",
      avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      role: "owner"
    });
    
    const user2 = this.createUser({
      username: "sarah_kim",
      password: "password123",
      displayName: "Sarah Kim",
      email: "sarah@example.com",
      avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      role: "admin"
    });
    
    const user3 = this.createUser({
      username: "michael_chen",
      password: "password123",
      displayName: "Michael Chen",
      email: "michael@example.com",
      avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      role: "member"
    });
    
    const user4 = this.createUser({
      username: "jessica_wilson",
      password: "password123",
      displayName: "Jessica Wilson",
      email: "jessica@example.com",
      avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      role: "member"
    });
    
    // Create templates - this creates 20 premade templates
    this.createTemplateData();
    
    // Create events
    const now = new Date();
    const campingEvent = this.createEvent({
      name: "Summer Camping Trip 2023",
      description: "Annual camping trip to Lake Tahoe",
      location: "Lake Tahoe",
      startDate: addDays(now, 12),
      endDate: addDays(now, 17),
      createdBy: 1
    });
    
    // Create event members
    this.createEventMember({ userId: 1, eventId: 1, role: "owner" });
    this.createEventMember({ userId: 2, eventId: 1, role: "admin" });
    this.createEventMember({ userId: 3, eventId: 1, role: "member" });
    this.createEventMember({ userId: 4, eventId: 1, role: "member" });
    
    // Create categories
    const campingGearCategory = this.createCategory({ name: "Camping Gear", eventId: 1 });
    const foodCategory = this.createCategory({ name: "Food & Cooking", eventId: 1 });
    const clothingCategory = this.createCategory({ name: "Clothing", eventId: 1 });
    const electronicsCategory = this.createCategory({ name: "Electronics", eventId: 1 });
    const hygieneCategory = this.createCategory({ name: "Hygiene", eventId: 1 });
    
    // Create items for Camping Gear
    this.createItem({ name: "Tent", description: "4-person tent", categoryId: 1, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 1, notes: "Check for tears" });
    this.createItem({ name: "Sleeping Bag", description: "Rated for 30°F", categoryId: 1, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 2, notes: "Bring the newer ones" });
    this.createItem({ name: "Camping Chairs", description: "Foldable", categoryId: 1, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 4, notes: "" });
    this.createItem({ name: "Tarp", description: "Ground cover", categoryId: 1, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 2, notes: "" });
    this.createItem({ name: "Camp Table", description: "Foldable", categoryId: 1, eventId: 1, assignedTo: 3, status: "to_pack", createdBy: 3, quantity: 1, notes: "" });
    this.createItem({ name: "Lantern", description: "LED", categoryId: 1, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 2, notes: "Bring extra batteries" });
    this.createItem({ name: "Flashlight", description: "Waterproof", categoryId: 1, eventId: 1, assignedTo: 3, status: "to_pack", createdBy: 3, quantity: 3, notes: "" });
    this.createItem({ name: "Pocket Knife", description: "Multi-tool", categoryId: 1, eventId: 1, assignedTo: 1, status: "to_pack", createdBy: 1, quantity: 1, notes: "" });
    this.createItem({ name: "Rope", description: "50 ft", categoryId: 1, eventId: 1, assignedTo: 3, status: "to_pack", createdBy: 3, quantity: 1, notes: "" });
    this.createItem({ name: "First Aid Kit", description: "Basic", categoryId: 1, eventId: 1, assignedTo: 4, status: "delivered", createdBy: 4, quantity: 1, notes: "Check expiration dates" });
    this.createItem({ name: "Insect Repellent", description: "", categoryId: 1, eventId: 1, assignedTo: 4, status: "packed", createdBy: 4, quantity: 2, notes: "" });
    this.createItem({ name: "Sunscreen", description: "SPF 50", categoryId: 1, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 2, notes: "" });

    // Create items for Food & Cooking
    this.createItem({ name: "Portable Stove", description: "2-burner", categoryId: 2, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 1, notes: "" });
    this.createItem({ name: "Cooler", description: "Large", categoryId: 2, eventId: 1, assignedTo: 3, status: "to_pack", createdBy: 3, quantity: 1, notes: "Fill with ice on departure day" });
    this.createItem({ name: "Pots & Pans", description: "", categoryId: 2, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 1, notes: "Bring the cast iron skillet" });
    this.createItem({ name: "Plates & Utensils", description: "Reusable", categoryId: 2, eventId: 1, assignedTo: 4, status: "packed", createdBy: 4, quantity: 6, notes: "" });
    this.createItem({ name: "Coffee Maker", description: "French press", categoryId: 2, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 1, notes: "" });
    this.createItem({ name: "Water Jugs", description: "5 gallon", categoryId: 2, eventId: 1, assignedTo: 3, status: "to_pack", createdBy: 3, quantity: 2, notes: "Fill before departure" });
    this.createItem({ name: "Trash Bags", description: "", categoryId: 2, eventId: 1, assignedTo: 4, status: "to_pack", createdBy: 4, quantity: 1, notes: "Box of heavy-duty bags" });
    this.createItem({ name: "Food Supplies", description: "Non-perishables", categoryId: 2, eventId: 1, assignedTo: 2, status: "to_pack", createdBy: 2, quantity: 1, notes: "Make a separate grocery list" });

    // Create items for Clothing
    this.createItem({ name: "Hiking Boots", description: "Waterproof", categoryId: 3, eventId: 1, assignedTo: 3, status: "packed", createdBy: 3, quantity: 4, notes: "" });
    this.createItem({ name: "Rain Jackets", description: "", categoryId: 3, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 4, notes: "" });
    this.createItem({ name: "Warm Layers", description: "Fleece, etc.", categoryId: 3, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 4, notes: "Check weather forecast" });
    this.createItem({ name: "Hiking Socks", description: "Wool", categoryId: 3, eventId: 1, assignedTo: 4, status: "packed", createdBy: 4, quantity: 12, notes: "" });
    this.createItem({ name: "Hats", description: "Sun protection", categoryId: 3, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 4, notes: "" });
    this.createItem({ name: "Gloves", description: "", categoryId: 3, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 4, notes: "" });
    this.createItem({ name: "Swimwear", description: "", categoryId: 3, eventId: 1, assignedTo: 3, status: "packed", createdBy: 3, quantity: 4, notes: "" });
    this.createItem({ name: "Extra Shoes", description: "Water shoes", categoryId: 3, eventId: 1, assignedTo: 4, status: "packed", createdBy: 4, quantity: 4, notes: "" });
    this.createItem({ name: "Sunglasses", description: "", categoryId: 3, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 4, notes: "" });
    this.createItem({ name: "Sleeping Clothes", description: "", categoryId: 3, eventId: 1, assignedTo: 2, status: "packed", createdBy: 2, quantity: 4, notes: "" });

    // Create items for Electronics
    this.createItem({ name: "Cameras", description: "DSLR + GoPro", categoryId: 4, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 2, notes: "Bring extra memory cards" });
    this.createItem({ name: "Phones", description: "", categoryId: 4, eventId: 1, assignedTo: 1, status: "packed", createdBy: 1, quantity: 4, notes: "" });
    this.createItem({ name: "Portable Speakers", description: "Bluetooth", categoryId: 4, eventId: 1, assignedTo: 3, status: "to_pack", createdBy: 3, quantity: 1, notes: "" });
    this.createItem({ name: "Power Banks", description: "High capacity", categoryId: 4, eventId: 1, assignedTo: 2, status: "to_pack", createdBy: 2, quantity: 2, notes: "Charge fully before trip" });
    this.createItem({ name: "Solar Charger", description: "", categoryId: 4, eventId: 1, assignedTo: 1, status: "to_pack", createdBy: 1, quantity: 1, notes: "" });
    this.createItem({ name: "GPS Device", description: "Handheld", categoryId: 4, eventId: 1, assignedTo: 4, status: "to_pack", createdBy: 4, quantity: 1, notes: "Update maps" });
    this.createItem({ name: "Headlamps", description: "LED", categoryId: 4, eventId: 1, assignedTo: 3, status: "packed", createdBy: 3, quantity: 4, notes: "" });

    // Create items for Hygiene
    this.createItem({ name: "Toiletries", description: "Basic kit", categoryId: 5, eventId: 1, assignedTo: 4, status: "to_pack", createdBy: 4, quantity: 4, notes: "" });
    this.createItem({ name: "Towels", description: "Quick-dry", categoryId: 5, eventId: 1, assignedTo: 2, status: "to_pack", createdBy: 2, quantity: 4, notes: "" });
    this.createItem({ name: "Hand Sanitizer", description: "", categoryId: 5, eventId: 1, assignedTo: 3, status: "to_pack", createdBy: 3, quantity: 2, notes: "" });
    this.createItem({ name: "Biodegradable Soap", description: "", categoryId: 5, eventId: 1, assignedTo: 1, status: "to_pack", createdBy: 1, quantity: 1, notes: "" });
    this.createItem({ name: "Toilet Paper", description: "", categoryId: 5, eventId: 1, assignedTo: 4, status: "packed", createdBy: 4, quantity: 2, notes: "" });

    // Create event milestones
    this.createMilestone({ 
      eventId: 1, 
      name: "Planning", 
      date: subDays(now, 10), 
      completed: true 
    });
    
    this.createMilestone({ 
      eventId: 1, 
      name: "Shopping", 
      date: subDays(now, 3), 
      completed: true 
    });
    
    this.createMilestone({ 
      eventId: 1, 
      name: "Equipment Check", 
      date: addDays(now, 4), 
      completed: false 
    });
    
    this.createMilestone({ 
      eventId: 1, 
      name: "Departure", 
      date: addDays(now, 12), 
      completed: false 
    });
    
    this.createMilestone({ 
      eventId: 1, 
      name: "Return", 
      date: addDays(now, 17), 
      completed: false 
    });

    // Create activities
    this.createActivity({
      userId: 2,
      eventId: 1,
      itemId: 13,
      action: "status_changed",
      details: { 
        oldStatus: "to_pack", 
        newStatus: "packed" 
      }
    });
    
    this.createActivity({
      userId: 3,
      eventId: 1,
      itemId: 19,
      action: "created",
      details: { 
        itemName: "Hiking Boots" 
      }
    });
    
    this.createActivity({
      userId: 1,
      eventId: 1,
      itemId: null,
      action: "created",
      details: { 
        event: "Summer Camping Trip 2023" 
      }
    });
    
    this.createActivity({
      userId: 4,
      eventId: 1,
      itemId: 10,
      action: "status_changed",
      details: { 
        oldStatus: "packed", 
        newStatus: "delivered" 
      }
    });
    
    this.createActivity({
      userId: 0, // System
      eventId: 1,
      itemId: null,
      action: "system",
      details: { 
        message: "Detected a duplicate item: Solar Power Bank" 
      }
    });
  }
  
  // Create template data for 20 premade templates
  private createTemplateData() {
    // Template 1: Camping Trip
    const campingTemplate = this.createTemplate({
      name: "Camping Trip",
      description: "Essential items for a standard camping trip",
      type: "outdoor",
      thumbnail: "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 1
    });
    
    // Create categories for camping template
    const campingGearCat = this.createTemplateCategory({ name: "Camping Gear", templateId: 1 });
    const campingFoodCat = this.createTemplateCategory({ name: "Food & Cooking", templateId: 1 });
    const campingClothingCat = this.createTemplateCategory({ name: "Clothing", templateId: 1 });
    
    // Create items for camping gear
    this.createTemplateItem({ name: "Tent", description: "Suitable for your group size", templateCategoryId: 1, templateId: 1, quantity: 1 });
    this.createTemplateItem({ name: "Sleeping Bag", description: "Check temperature rating", templateCategoryId: 1, templateId: 1, quantity: 1 });
    this.createTemplateItem({ name: "Camping Chairs", description: "Foldable", templateCategoryId: 1, templateId: 1, quantity: 4 });
    
    // Template 2: Beach Vacation
    const beachTemplate = this.createTemplate({
      name: "Beach Vacation",
      description: "Everything you need for a perfect beach getaway",
      type: "vacation",
      thumbnail: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 1
    });
    
    // Create categories for beach template
    const beachEssentialsCat = this.createTemplateCategory({ name: "Beach Essentials", templateId: 2 });
    const beachClothingCat = this.createTemplateCategory({ name: "Clothing", templateId: 2 });
    
    // Create items for beach essentials
    this.createTemplateItem({ name: "Beach Umbrella", description: "For shade", templateCategoryId: 4, templateId: 2, quantity: 1 });
    this.createTemplateItem({ name: "Sunscreen", description: "SPF 30+", templateCategoryId: 4, templateId: 2, quantity: 2 });
    
    // Template 3: Ski Trip
    const skiTemplate = this.createTemplate({
      name: "Ski Trip",
      description: "Complete packing list for a winter ski vacation",
      type: "winter",
      thumbnail: "https://images.unsplash.com/photo-1551524559-8af4e6624178?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 2
    });
    
    // Template 4: Business Conference
    const businessTemplate = this.createTemplate({
      name: "Business Conference",
      description: "Professional essentials for business travel",
      type: "business",
      thumbnail: "https://images.unsplash.com/photo-1565688534245-05d6b5be184a?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 2
    });
    
    // Template 5: Music Festival
    const festivalTemplate = this.createTemplate({
      name: "Music Festival",
      description: "Don't forget these festival essentials",
      type: "entertainment",
      thumbnail: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6a3?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 3
    });
    
    // Template 6: Road Trip
    this.createTemplate({
      name: "Road Trip",
      description: "Everything needed for a cross-country adventure",
      type: "travel",
      thumbnail: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 1
    });
    
    // Template 7: Family Vacation
    this.createTemplate({
      name: "Family Vacation",
      description: "Complete packing list for the whole family",
      type: "vacation",
      thumbnail: "https://images.unsplash.com/photo-1602002418816-5c0aeef426aa?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 4
    });
    
    // Template 8: Backpacking Trip
    this.createTemplate({
      name: "Backpacking Trip",
      description: "Lightweight essentials for long-distance hiking",
      type: "outdoor",
      thumbnail: "https://images.unsplash.com/photo-1501555088652-021faa106b9b?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 3
    });
    
    // Template 9: Weekend Getaway
    this.createTemplate({
      name: "Weekend Getaway",
      description: "Quick trip essentials for a short break",
      type: "travel",
      thumbnail: "https://images.unsplash.com/photo-1523544932615-a9b4a3640ece?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 2
    });
    
    // Template 10: International Travel
    this.createTemplate({
      name: "International Travel",
      description: "Important items for overseas adventures",
      type: "travel",
      thumbnail: "https://images.unsplash.com/photo-1503221043305-f7498f8b7888?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 1
    });
    
    // Template 11: Cycling Trip
    this.createTemplate({
      name: "Cycling Trip",
      description: "Essential gear for bike touring adventures",
      type: "outdoor",
      thumbnail: "https://images.unsplash.com/photo-1541625602330-2277a4c46182?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 3
    });
    
    // Template 12: Wedding Planning
    this.createTemplate({
      name: "Wedding Planning",
      description: "Detailed checklist for your special day",
      type: "event",
      thumbnail: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 4
    });
    
    // Template 13: House Moving
    this.createTemplate({
      name: "House Moving",
      description: "Complete moving day organization",
      type: "home",
      thumbnail: "https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 2
    });
    
    // Template 14: Baby Shower
    this.createTemplate({
      name: "Baby Shower",
      description: "Everything for hosting a perfect celebration",
      type: "event",
      thumbnail: "https://images.unsplash.com/photo-1515923152115-758a6b16f35e?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 4
    });
    
    // Template 15: College Dorm
    this.createTemplate({
      name: "College Dorm",
      description: "Essential items for student life",
      type: "education",
      thumbnail: "https://images.unsplash.com/photo-1567168544813-cc03465b4fa8?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 3
    });
    
    // Template 16: Photography Gear
    this.createTemplate({
      name: "Photography Gear",
      description: "Complete photography equipment checklist",
      type: "hobby",
      thumbnail: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 1
    });
    
    // Template 17: Fishing Trip
    this.createTemplate({
      name: "Fishing Trip",
      description: "All the gear for a successful fishing adventure",
      type: "outdoor",
      thumbnail: "https://images.unsplash.com/photo-1574871935907-993dde0f9f1f?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 2
    });
    
    // Template 18: Yoga Retreat
    this.createTemplate({
      name: "Yoga Retreat",
      description: "Packing essentials for mindfulness and wellness",
      type: "wellness",
      thumbnail: "https://images.unsplash.com/photo-1545389336-cf090694435e?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 4
    });
    
    // Template 19: Emergency Kit
    this.createTemplate({
      name: "Emergency Kit",
      description: "Essential preparation for natural disasters",
      type: "safety",
      thumbnail: "https://images.unsplash.com/photo-1563453392212-326f5e854473?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 1
    });
    
    // Template 20: Cruise Vacation
    this.createTemplate({
      name: "Cruise Vacation",
      description: "Everything you need for a cruise ship adventure",
      type: "vacation",
      thumbnail: "https://images.unsplash.com/photo-1548574505-5e239809ee19?w=600&auto=format&fit=crop",
      isPublic: true,
      createdBy: 3
    });
  }
}

// Use the DatabaseStorage instead of MemStorage for persistent data
export const storage = new DatabaseStorage();