import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  email: text("email").notNull(),
  avatarUrl: text("avatar_url"),
  role: text("role").notNull().default("member"), // owner, admin, member, viewer
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  email: true,
  avatarUrl: true,
  role: true,
});

// Event model
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  location: text("location"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  templateId: integer("template_id"),
});

export const insertEventSchema = createInsertSchema(events).pick({
  name: true,
  description: true,
  location: true,
  startDate: true,
  endDate: true,
  createdBy: true,
  templateId: true,
});

// Event Milestone model
export const eventMilestones = pgTable("event_milestones", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull(),
  name: text("name").notNull(),
  date: timestamp("date").notNull(),
  completed: boolean("completed").notNull().default(false),
});

export const insertEventMilestoneSchema = createInsertSchema(eventMilestones).pick({
  eventId: true,
  name: true,
  date: true,
  completed: true,
});

// Category model
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  eventId: integer("event_id").notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  eventId: true,
});

// Item model
export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  categoryId: integer("category_id").notNull(),
  eventId: integer("event_id").notNull(),
  assignedTo: integer("assigned_to"),
  status: text("status").notNull().default("to_pack"), // to_pack, packed, delivered
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at"),
  quantity: integer("quantity").notNull().default(1),
  notes: text("notes"),
});

export const insertItemSchema = createInsertSchema(items).pick({
  name: true,
  description: true,
  categoryId: true,
  eventId: true,
  assignedTo: true,
  status: true,
  createdBy: true,
  quantity: true,
  notes: true,
});

// Activity model
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  eventId: integer("event_id").notNull(),
  itemId: integer("item_id"),
  action: text("action").notNull(), // created, updated, deleted, status_changed
  details: json("details"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  userId: true,
  eventId: true,
  itemId: true,
  action: true,
  details: true,
});

// EventMember model (join table for users and events)
export const eventMembers = pgTable("event_members", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  eventId: integer("event_id").notNull(),
  role: text("role").notNull().default("member"), // owner, admin, member, viewer
});

export const insertEventMemberSchema = createInsertSchema(eventMembers).pick({
  userId: true,
  eventId: true,
  role: true,
});

// Template model for predefined event types
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(), // camping, vacation, party, etc.
  thumbnail: text("thumbnail"),
  isPublic: boolean("is_public").notNull().default(true),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTemplateSchema = createInsertSchema(templates).pick({
  name: true,
  description: true,
  type: true,
  thumbnail: true,
  isPublic: true,
  createdBy: true,
});

// Template Category model
export const templateCategories = pgTable("template_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  templateId: integer("template_id").notNull(),
});

export const insertTemplateCategorySchema = createInsertSchema(templateCategories).pick({
  name: true,
  templateId: true,
});

// Template Item model
export const templateItems = pgTable("template_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  templateCategoryId: integer("template_category_id").notNull(),
  templateId: integer("template_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  notes: text("notes"),
});

export const insertTemplateItemSchema = createInsertSchema(templateItems).pick({
  name: true,
  description: true,
  templateCategoryId: true,
  templateId: true,
  quantity: true,
  notes: true,
});

// Define relations between models

// User relations
export const usersRelations = relations(users, ({ many }) => ({
  eventMembers: many(eventMembers),
  createdEvents: many(events, { relationName: "createdBy" }),
  createdTemplates: many(templates, { relationName: "createdBy" }),
  items: many(items, { relationName: "assignedTo" }),
  activities: many(activities)
}));

// Event relations
export const eventsRelations = relations(events, ({ one, many }) => ({
  creator: one(users, {
    fields: [events.createdBy],
    references: [users.id],
    relationName: "createdBy"
  }),
  template: one(templates, {
    fields: [events.templateId],
    references: [templates.id]
  }),
  categories: many(categories),
  items: many(items),
  milestones: many(eventMilestones),
  members: many(eventMembers),
  activities: many(activities)
}));

// EventMilestones relations
export const eventMilestonesRelations = relations(eventMilestones, ({ one }) => ({
  event: one(events, {
    fields: [eventMilestones.eventId],
    references: [events.id]
  })
}));

// Categories relations
export const categoriesRelations = relations(categories, ({ one, many }) => ({
  event: one(events, {
    fields: [categories.eventId],
    references: [events.id]
  }),
  items: many(items)
}));

// Items relations
export const itemsRelations = relations(items, ({ one, many }) => ({
  category: one(categories, {
    fields: [items.categoryId],
    references: [categories.id]
  }),
  event: one(events, {
    fields: [items.eventId],
    references: [events.id]
  }),
  assignedUser: one(users, {
    fields: [items.assignedTo],
    references: [users.id],
    relationName: "assignedTo"
  }),
  creator: one(users, {
    fields: [items.createdBy],
    references: [users.id],
    relationName: "createdBy"
  }),
  activities: many(activities)
}));

// Activities relations
export const activitiesRelations = relations(activities, ({ one }) => ({
  user: one(users, {
    fields: [activities.userId],
    references: [users.id]
  }),
  event: one(events, {
    fields: [activities.eventId],
    references: [events.id]
  }),
  item: one(items, {
    fields: [activities.itemId],
    references: [items.id]
  })
}));

// EventMembers relations
export const eventMembersRelations = relations(eventMembers, ({ one }) => ({
  user: one(users, {
    fields: [eventMembers.userId],
    references: [users.id]
  }),
  event: one(events, {
    fields: [eventMembers.eventId],
    references: [events.id]
  })
}));

// Template relations
export const templatesRelations = relations(templates, ({ one, many }) => ({
  creator: one(users, {
    fields: [templates.createdBy],
    references: [users.id],
    relationName: "createdBy"
  }),
  categories: many(templateCategories),
  items: many(templateItems),
  events: many(events)
}));

// TemplateCategories relations
export const templateCategoriesRelations = relations(templateCategories, ({ one, many }) => ({
  template: one(templates, {
    fields: [templateCategories.templateId],
    references: [templates.id]
  }),
  items: many(templateItems)
}));

// TemplateItems relations
export const templateItemsRelations = relations(templateItems, ({ one }) => ({
  template: one(templates, {
    fields: [templateItems.templateId],
    references: [templates.id]
  }),
  category: one(templateCategories, {
    fields: [templateItems.templateCategoryId],
    references: [templateCategories.id]
  })
}));

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type EventMilestone = typeof eventMilestones.$inferSelect;
export type InsertEventMilestone = z.infer<typeof insertEventMilestoneSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Item = typeof items.$inferSelect;
export type InsertItem = z.infer<typeof insertItemSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type EventMember = typeof eventMembers.$inferSelect;
export type InsertEventMember = z.infer<typeof insertEventMemberSchema>;

export type Template = typeof templates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;

export type TemplateCategory = typeof templateCategories.$inferSelect;
export type InsertTemplateCategory = z.infer<typeof insertTemplateCategorySchema>;

export type TemplateItem = typeof templateItems.$inferSelect;
export type InsertTemplateItem = z.infer<typeof insertTemplateItemSchema>;
