import DashboardLayout from "@/components/dashboard/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("profile");
  
  // Mock user profile data
  const user = {
    id: 1,
    displayName: "John Doe",
    username: "johndoe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    avatarUrl: "https://ui-avatars.com/api/?name=John+Doe&background=0D8ABC&color=fff",
    role: "Owner",
    bio: "Event organizer and outdoor enthusiast with a passion for well-organized group adventures.",
    joinedDate: "January 2023",
    location: "Seattle, WA"
  };
  
  // Mock notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    emailUpdates: true,
    itemAssigned: true,
    statusChange: true,
    newMember: true,
    reminderBefore: true,
    weeklyDigest: false,
    marketing: false,
  });
  
  // Handler for notification toggle
  const handleNotificationToggle = (setting: string) => {
    setNotificationSettings({
      ...notificationSettings,
      [setting]: !notificationSettings[setting as keyof typeof notificationSettings]
    });
  };
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600 mt-1">Manage your account settings and preferences</p>
        </div>
        
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-3 md:w-[400px]">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
          </TabsList>
          
          {/* Profile Settings */}
          <TabsContent value="profile">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Information</CardTitle>
                    <CardDescription>
                      Update your personal information and public profile
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="display-name">Display Name</Label>
                        <Input id="display-name" defaultValue={user.displayName} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="username">Username</Label>
                        <Input id="username" defaultValue={user.username} />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" defaultValue={user.email} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input id="phone" type="tel" defaultValue={user.phone} />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input id="location" defaultValue={user.location} />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea id="bio" defaultValue={user.bio} />
                      <p className="text-xs text-gray-500">Brief description for your profile. This will be displayed publicly.</p>
                    </div>
                  </CardContent>
                  <CardFooter className="justify-end space-x-2">
                    <Button variant="outline">Cancel</Button>
                    <Button>Save Changes</Button>
                  </CardFooter>
                </Card>
              </div>
              
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Picture</CardTitle>
                    <CardDescription>
                      Update your profile photo
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center">
                    <Avatar className="h-24 w-24 mb-4">
                      <AvatarImage src={user.avatarUrl} alt={user.displayName} />
                      <AvatarFallback>{user.displayName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col space-y-2 w-full">
                      <Button variant="outline" size="sm">Upload New Photo</Button>
                      <Button variant="ghost" size="sm">Remove Photo</Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Account Info</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Member Since</span>
                      <span className="text-sm">{user.joinedDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Role</span>
                      <span className="text-sm">{user.role}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Account ID</span>
                      <span className="text-sm">#{user.id}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          {/* Notification Settings */}
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>
                  Control how and when you receive notifications
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Event Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="item-assigned" className="text-base">Item Assignments</Label>
                        <p className="text-sm text-gray-500">Receive notifications when items are assigned to you</p>
                      </div>
                      <Switch 
                        id="item-assigned" 
                        checked={notificationSettings.itemAssigned}
                        onCheckedChange={() => handleNotificationToggle('itemAssigned')}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="status-change" className="text-base">Status Changes</Label>
                        <p className="text-sm text-gray-500">Notify when item status changes (packed, delivered, etc.)</p>
                      </div>
                      <Switch 
                        id="status-change" 
                        checked={notificationSettings.statusChange}
                        onCheckedChange={() => handleNotificationToggle('statusChange')}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="new-member" className="text-base">New Team Members</Label>
                        <p className="text-sm text-gray-500">Notify when someone joins the event team</p>
                      </div>
                      <Switch 
                        id="new-member" 
                        checked={notificationSettings.newMember}
                        onCheckedChange={() => handleNotificationToggle('newMember')}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="reminder-before" className="text-base">Event Reminders</Label>
                        <p className="text-sm text-gray-500">Send reminders before event deadlines and start dates</p>
                      </div>
                      <Switch 
                        id="reminder-before" 
                        checked={notificationSettings.reminderBefore}
                        onCheckedChange={() => handleNotificationToggle('reminderBefore')}
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Email Communication</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="email-updates" className="text-base">Email Updates</Label>
                        <p className="text-sm text-gray-500">Receive general email updates about events</p>
                      </div>
                      <Switch 
                        id="email-updates" 
                        checked={notificationSettings.emailUpdates}
                        onCheckedChange={() => handleNotificationToggle('emailUpdates')}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="weekly-digest" className="text-base">Weekly Digest</Label>
                        <p className="text-sm text-gray-500">Receive a weekly summary of all activity</p>
                      </div>
                      <Switch 
                        id="weekly-digest" 
                        checked={notificationSettings.weeklyDigest}
                        onCheckedChange={() => handleNotificationToggle('weeklyDigest')}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="marketing" className="text-base">Marketing Emails</Label>
                        <p className="text-sm text-gray-500">Receive promotional offers and updates</p>
                      </div>
                      <Switch 
                        id="marketing" 
                        checked={notificationSettings.marketing}
                        onCheckedChange={() => handleNotificationToggle('marketing')}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="justify-end">
                <Button>Save Preferences</Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Account Settings */}
          <TabsContent value="account">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Password & Security</CardTitle>
                  <CardDescription>
                    Update your password and security settings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input id="current-password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input id="new-password" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input id="confirm-password" type="password" />
                  </div>
                </CardContent>
                <CardFooter className="justify-end space-x-2">
                  <Button variant="outline">Cancel</Button>
                  <Button>Update Password</Button>
                </CardFooter>
              </Card>
              
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Two-Factor Authentication</CardTitle>
                    <CardDescription>
                      Add an extra layer of security to your account
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-primary-50 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-primary-700">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-medium">Protect your account with 2FA</p>
                        <p className="text-sm text-gray-500">Two-factor authentication adds an extra layer of security to your account.</p>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full">Set up 2FA</Button>
                  </CardContent>
                </Card>
                
                <Card className="border-red-100">
                  <CardHeader>
                    <CardTitle className="text-red-600">Danger Zone</CardTitle>
                    <CardDescription>
                      Irreversible account actions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button variant="destructive" className="w-full">Delete Account</Button>
                    <p className="text-xs text-gray-500 text-center">This action is permanent and cannot be undone. All your data will be permanently deleted.</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}