import DashboardLayout from "@/components/dashboard/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { UserPlus, Mail, Phone, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function Team() {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Mock team data
  const teamMembers = [
    {
      id: 1,
      name: "John Doe",
      role: "Owner",
      email: "john@example.com",
      phone: "+1 (555) 123-4567",
      avatarUrl: "https://ui-avatars.com/api/?name=John+Doe&background=0D8ABC&color=fff",
      assignedItems: 12,
      lastActive: "Just now"
    },
    {
      id: 2,
      name: "Jane Smith",
      role: "Admin",
      email: "jane@example.com",
      phone: "+1 (555) 234-5678",
      avatarUrl: "https://ui-avatars.com/api/?name=Jane+Smith&background=F06292&color=fff",
      assignedItems: 8,
      lastActive: "10 minutes ago"
    },
    {
      id: 3,
      name: "Bob Williams",
      role: "Member",
      email: "bob@example.com",
      phone: "+1 (555) 345-6789",
      avatarUrl: "https://ui-avatars.com/api/?name=Bob+Williams&background=4CAF50&color=fff",
      assignedItems: 5,
      lastActive: "2 hours ago"
    },
    {
      id: 4,
      name: "Sarah Parker",
      role: "Member",
      email: "sarah@example.com",
      phone: "+1 (555) 456-7890",
      avatarUrl: "https://ui-avatars.com/api/?name=Sarah+Parker&background=FF9800&color=fff",
      assignedItems: 3,
      lastActive: "1 day ago"
    }
  ];
  
  // Filter team members based on search term
  const filteredMembers = teamMembers.filter(member => 
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Get role badge styling
  const getRoleBadge = (role: string) => {
    switch(role.toLowerCase()) {
      case "owner":
        return "bg-primary-100 text-primary-800";
      case "admin":
        return "bg-green-100 text-green-800";
      case "member":
        return "bg-blue-100 text-blue-800";
      case "viewer":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Team Management</h1>
            <p className="text-gray-600 mt-1">Manage your event team members and their access</p>
          </div>
          <Button>
            <UserPlus className="h-4 w-4 mr-2" />
            Invite Member
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Members</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{teamMembers.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Admins</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-500">
                {teamMembers.filter(m => m.role.toLowerCase() === "admin").length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Members</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-500">
                {teamMembers.filter(m => m.role.toLowerCase() === "member").length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Owners</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary-500">
                {teamMembers.filter(m => m.role.toLowerCase() === "owner").length}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Team Members</CardTitle>
            <CardDescription>
              View and manage team members for this event
            </CardDescription>
            <div className="pt-4">
              <Input
                type="search"
                placeholder="Search by name, role, or email..."
                className="max-w-md"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMembers.map(member => (
                <Card key={member.id} className="overflow-hidden">
                  <div className="bg-primary-50 h-12"></div>
                  <div className="px-6 pb-6">
                    <div className="flex justify-between -mt-6">
                      <div className="relative">
                        <img 
                          src={member.avatarUrl} 
                          alt={member.name}
                          className="h-12 w-12 rounded-full border-2 border-white"
                        />
                      </div>
                      <div className="flex items-start pt-2">
                        <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${getRoleBadge(member.role)}`}>
                          {member.role}
                        </span>
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-semibold mt-4">{member.name}</h3>
                    
                    <div className="mt-4 space-y-3 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Mail className="h-4 w-4 mr-2 text-gray-400" />
                        <span>{member.email}</span>
                      </div>
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 mr-2 text-gray-400" />
                        <span>{member.phone}</span>
                      </div>
                      <div className="flex items-center">
                        <Shield className="h-4 w-4 mr-2 text-gray-400" />
                        <span>{member.assignedItems} items assigned</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between items-center">
                      <span className="text-xs text-gray-500">Last active: {member.lastActive}</span>
                      <Button variant="ghost" size="sm">Manage</Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}