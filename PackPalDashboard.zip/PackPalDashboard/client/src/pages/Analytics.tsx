import DashboardLayout from "@/components/dashboard/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, Cell, LineChart, Line, CartesianGrid } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";

// Mock Colors
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];
const ITEM_STATUS_COLORS = {
  to_pack: '#FFBB28',
  packed: '#00C49F',
  delivered: '#0088FE'
};

export default function Analytics() {
  const [eventFilter, setEventFilter] = useState("all");
  const [timeRange, setTimeRange] = useState("30days");
  
  // Mock analytics data
  
  // Status Distribution Data
  const statusData = [
    { name: 'To Pack', value: 15, color: ITEM_STATUS_COLORS.to_pack },
    { name: 'Packed', value: 25, color: ITEM_STATUS_COLORS.packed },
    { name: 'Delivered', value: 10, color: ITEM_STATUS_COLORS.delivered },
  ];
  
  // Category Distribution Data
  const categoryData = [
    { name: 'Shelter', count: 8 },
    { name: 'Food & Cooking', count: 12 },
    { name: 'Clothing', count: 10 },
    { name: 'Tools & Equipment', count: 15 },
    { name: 'First Aid & Safety', count: 5 },
  ];
  
  // Progress Over Time Data
  const progressData = [
    { day: '1', packed: 5, delivered: 2, total: 50 },
    { day: '5', packed: 12, delivered: 5, total: 50 },
    { day: '10', packed: 20, delivered: 8, total: 50 },
    { day: '15', packed: 25, delivered: 12, total: 50 },
    { day: '20', packed: 30, delivered: 15, total: 50 },
    { day: '25', packed: 35, delivered: 20, total: 50 },
    { day: '30', packed: 40, delivered: 25, total: 50 },
  ];
  
  // Member Activity Data
  const memberActivityData = [
    { name: 'John Doe', items: 12, completed: 9 },
    { name: 'Jane Smith', items: 8, completed: 7 },
    { name: 'Bob Williams', items: 5, completed: 2 },
    { name: 'Sarah Parker', items: 3, completed: 1 },
  ];
  
  // Status Pie Chart
  const renderStatusPieChart = () => {
    return (
      <ResponsiveContainer width="100%" height={240}>
        <PieChart>
          <Pie
            data={statusData}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {statusData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    );
  };
  
  // Category Bar Chart
  const renderCategoryBarChart = () => {
    return (
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={categoryData}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="count" fill="#3b82f6">
            {categoryData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    );
  };
  
  // Progress Line Chart
  const renderProgressLineChart = () => {
    return (
      <ResponsiveContainer width="100%" height={240}>
        <LineChart data={progressData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="day" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="packed" stroke="#00C49F" />
          <Line type="monotone" dataKey="delivered" stroke="#0088FE" />
        </LineChart>
      </ResponsiveContainer>
    );
  };
  
  // Member Activity Bar Chart
  const renderMemberActivityChart = () => {
    return (
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={memberActivityData} layout="vertical">
          <XAxis type="number" />
          <YAxis dataKey="name" type="category" />
          <Tooltip />
          <Legend />
          <Bar dataKey="items" stackId="a" fill="#8884d8" name="Total Items" />
          <Bar dataKey="completed" stackId="a" fill="#82ca9d" name="Completed" />
        </BarChart>
      </ResponsiveContainer>
    );
  };
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
            <p className="text-gray-600 mt-1">Track progress and analyze performance</p>
          </div>
          
          <div className="flex space-x-4">
            <Select value={eventFilter} onValueChange={setEventFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Event" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Events</SelectItem>
                <SelectItem value="1">Summer Camping Trip</SelectItem>
                <SelectItem value="2">Team Building Weekend</SelectItem>
                <SelectItem value="3">Product Launch Event</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Time Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="90days">Last 90 Days</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Overall Status</CardTitle>
              <CardDescription>Distribution of items by status</CardDescription>
            </CardHeader>
            <CardContent>
              {renderStatusPieChart()}
              <div className="flex justify-center gap-4 mt-4">
                {statusData.map((status, index) => (
                  <div key={index} className="flex items-center">
                    <div 
                      className="w-3 h-3 rounded-full mr-2" 
                      style={{ backgroundColor: status.color }}
                    />
                    <span className="text-sm text-gray-600">{status.name}: {status.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Items by Category</CardTitle>
              <CardDescription>Distribution of items across categories</CardDescription>
            </CardHeader>
            <CardContent>
              {renderCategoryBarChart()}
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Progress Over Time</CardTitle>
              <CardDescription>Tracking items packed and delivered</CardDescription>
            </CardHeader>
            <CardContent>
              {renderProgressLineChart()}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Team Member Activity</CardTitle>
              <CardDescription>Items assigned and completed by member</CardDescription>
            </CardHeader>
            <CardContent>
              {renderMemberActivityChart()}
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Key Insights</CardTitle>
            <CardDescription>Important trends and observations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                <h3 className="font-medium text-blue-800">Packing Progress</h3>
                <p className="text-blue-700 mt-1">
                  80% of items have been either packed or delivered, which is ahead of schedule compared to previous events.
                </p>
              </div>
              
              <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                <h3 className="font-medium text-green-800">Category Efficiency</h3>
                <p className="text-green-700 mt-1">
                  The "Food & Cooking" category has the highest completion rate at 92%, showing excellent preparation.
                </p>
              </div>
              
              <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-100">
                <h3 className="font-medium text-yellow-800">Team Performance</h3>
                <p className="text-yellow-700 mt-1">
                  Jane Smith has completed 87.5% of assigned items, making her the most efficient team member.
                </p>
              </div>
              
              <div className="p-4 bg-purple-50 rounded-lg border border-purple-100">
                <h3 className="font-medium text-purple-800">Timeline Projection</h3>
                <p className="text-purple-700 mt-1">
                  At the current rate, all items will be packed 3 days before the event start date.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}