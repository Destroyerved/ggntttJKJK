import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Loader2, Search, Filter, Tag } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardFooter, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// Define the types for our templates data
interface Template {
  id: number;
  name: string;
  description: string | null;
  type: string;
  thumbnail: string;
  isPublic: boolean;
  createdBy: number;
  createdAt: string;
  categoryCount: number;
  itemCount: number;
}

interface TemplateType {
  type: string;
  count: number;
}

interface TemplatesData {
  templates: Template[];
  types: TemplateType[];
  totalCount: number;
}

export default function Templates() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');

  // Fetch templates data
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/templates'],
    retry: false,
    refetchOnWindowFocus: false,
  });

  const templatesData = data as TemplatesData;

  // Filter templates based on search query and selected type
  const filteredTemplates = templatesData?.templates.filter(template => {
    const matchesSearch = searchQuery === '' || 
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (template.description && template.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = selectedType === 'all' || template.type === selectedType;
    
    return matchesSearch && matchesType;
  });

  // Format the type name for display
  const formatTypeName = (type: string) => {
    return type.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-lg">Loading templates...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <p className="text-lg text-red-600">Failed to load templates</p>
        <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Templates</h1>
          <p className="text-muted-foreground">
            Choose from our {templatesData?.totalCount || 0} ready-made templates to get started
          </p>
        </div>
        
        <div className="flex items-center mt-4 md:mt-0">
          <Link href="/dashboard">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </div>

      {/* Filters and search */}
      <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-full md:w-[200px]">
            <div className="flex items-center">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Filter by type" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="all">All Types</SelectItem>
              {templatesData?.types.map((type) => (
                <SelectItem key={type.type} value={type.type}>
                  {formatTypeName(type.type)} ({type.count})
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>

      {/* Template cards */}
      {filteredTemplates?.length === 0 ? (
        <div className="text-center py-12 border rounded-lg">
          <p className="text-lg text-muted-foreground">No templates found matching your criteria</p>
          <Button 
            variant="link" 
            onClick={() => {
              setSearchQuery('');
              setSelectedType('all');
            }}
          >
            Clear filters
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates?.map((template) => (
            <Card key={template.id} className="flex flex-col overflow-hidden hover:shadow-md transition-shadow">
              <div 
                className="h-48 bg-cover bg-center" 
                style={{ backgroundImage: `url(${template.thumbnail})` }}
              />
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{template.name}</CardTitle>
                  <Badge variant="outline" className="text-xs">
                    <Tag className="h-3 w-3 mr-1" />
                    {formatTypeName(template.type)}
                  </Badge>
                </div>
                <CardDescription className="line-clamp-2">
                  {template.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-2 pt-0">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{template.categoryCount} categories</span>
                  <span>{template.itemCount} items</span>
                </div>
              </CardContent>
              <CardFooter className="pt-2 mt-auto">
                <Link href={`/templates/${template.id}`} className="w-full">
                  <Button variant="default" className="w-full">
                    View Template
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}