import { useState } from "react";
import DashboardLayout from "@/components/dashboard/DashboardLayout";
import StatsOverview from "@/components/dashboard/StatsOverview";
import EventTimeline from "@/components/dashboard/EventTimeline";
import ChecklistOverview from "@/components/dashboard/ChecklistOverview";
import TeamMembers from "@/components/dashboard/TeamMembers";
import RecentActivity from "@/components/dashboard/RecentActivity";
import QuickActions from "@/components/dashboard/QuickActions";
import { Plus, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import useDashboardData from "@/hooks/useDashboardData";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data, isLoading, error } = useDashboardData(1); // Get data for event ID 1
  
  // If loading, show skeleton UI
  if (isLoading) {
    return (
      <DashboardLoading />
    );
  }
  
  // If error, show error message
  if (error || !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <h1 className="text-2xl font-bold text-red-600 mb-2">Error Loading Dashboard</h1>
        <p className="text-gray-600 mb-4">There was a problem loading the dashboard data.</p>
        <Button onClick={() => window.location.reload()}>Try Again</Button>
      </div>
    );
  }
  
  // Get item counts by team member
  const getMemberItemCounts = () => {
    return data.members.map(member => ({
      ...member,
      itemCount: data.stats.totalItems / data.members.length // Evenly distribute for mockup
    }));
  };
  
  return (
    <DashboardLayout currentUser={{
      id: 1,
      displayName: "Alex Johnson",
      role: "Owner",
      avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    }}>
      {/* Page Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">{data.event.name}</h1>
            <p className="mt-1 text-sm text-gray-500">
              {new Date(data.event.startDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              {data.event.endDate && ` - ${new Date(data.event.endDate).toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: 'numeric' })}`}
              {data.event.location && ` • ${data.event.location}`}
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex space-x-3">
            <Button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none">
              <Plus className="mr-2 h-4 w-4" />
              New Checklist
            </Button>
            <Button variant="outline" className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
        {/* Stats Overview */}
        <StatsOverview stats={data.stats} />
        
        {/* Event Timeline */}
        <div className="mt-8">
          <EventTimeline timeline={data.timeline} />
        </div>
        
        {/* Checklist Overview & Team Members */}
        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
          <ChecklistOverview categoryProgress={data.categoryProgress} />
          <TeamMembers members={getMemberItemCounts()} />
        </div>
        
        {/* Recent Activity */}
        <div className="mt-8">
          <RecentActivity activities={data.activities} />
        </div>
        
        {/* Quick Actions */}
        <div className="mt-8">
          <QuickActions />
        </div>
      </div>
    </DashboardLayout>
  );
}

// Loading skeleton component
function DashboardLoading() {
  return (
    <DashboardLayout currentUser={{
      id: 1,
      displayName: "Alex Johnson",
      role: "Owner",
      avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    }}>
      {/* Page Header Skeleton */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
          
          <div className="mt-4 md:mt-0 flex space-x-3">
            <Skeleton className="h-10 w-36" />
            <Skeleton className="h-10 w-28" />
          </div>
        </div>
      </div>

      {/* Dashboard Content Skeletons */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-8">
        {/* Stats Overview Skeleton */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white overflow-hidden shadow rounded-lg p-6">
              <Skeleton className="h-16 w-full" />
            </div>
          ))}
        </div>
        
        {/* Event Timeline Skeleton */}
        <div className="mt-8">
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6">
              <Skeleton className="h-6 w-48 mb-2" />
              <Skeleton className="h-4 w-64" />
            </div>
            <div className="border-t border-gray-200 p-6">
              <Skeleton className="h-24 w-full" />
            </div>
          </div>
        </div>
        
        {/* Other Sections Skeleton */}
        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
            <Skeleton className="h-6 w-48 mb-6" />
            <Skeleton className="h-4 w-full mb-4" />
            <Skeleton className="h-4 w-full mb-4" />
            <Skeleton className="h-4 w-full mb-4" />
            <Skeleton className="h-4 w-full mb-4" />
            <Skeleton className="h-4 w-full" />
          </div>
          <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
            <Skeleton className="h-6 w-48 mb-6" />
            <Skeleton className="h-12 w-full mb-3" />
            <Skeleton className="h-12 w-full mb-3" />
            <Skeleton className="h-12 w-full mb-3" />
            <Skeleton className="h-12 w-full" />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
