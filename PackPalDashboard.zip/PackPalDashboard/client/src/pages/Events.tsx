import DashboardLayout from "@/components/dashboard/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { CalendarPlus, Calendar, MapPin, Clock, User, Package, ChevronRight, CalendarDays, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { format, addDays } from "date-fns";
import { useLocation } from "wouter";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";

export default function Events() {
  const [searchTerm, setSearchTerm] = useState("");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Dialog states
  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false);
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  
  // Form states
  const [eventName, setEventName] = useState("");
  const [eventDescription, setEventDescription] = useState("");
  const [eventLocation, setEventLocation] = useState("");
  const [startDate, setStartDate] = useState<Date | undefined>(new Date());
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [shareOption, setShareOption] = useState("link");
  const [emailAddresses, setEmailAddresses] = useState("");
  const [emailMessage, setEmailMessage] = useState("Check out this event on PackPal!");
  
  // Handle creating a new event
  const handleCreateEvent = () => {
    if (!eventName || !startDate) {
      toast({
        title: "Missing Information",
        description: "Please fill out all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Event Created",
      description: "Your new event has been created successfully."
    });
    
    setIsCreateEventOpen(false);
    
    // Reset form fields
    setEventName("");
    setEventDescription("");
    setEventLocation("");
    setStartDate(new Date());
    setEndDate(undefined);
  };
  
  // Handle view details button click
  const handleViewDetails = (event: any) => {
    navigate(`/dashboard?event=${event.id}`);
  };
  
  // Handle share button click
  const handleShare = () => {
    if (shareOption === "link") {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Event link copied to clipboard. You can now share it with anyone.",
      });
    } else {
      toast({
        title: "Shared Successfully",
        description: `Event details shared via ${shareOption}.`,
      });
    }
    setIsShareDialogOpen(false);
  };
  
  // Mock events data
  const events = [
    {
      id: 1,
      name: "Summer Camping Trip",
      description: "Annual company retreat in the mountains",
      location: "Mount Rainier National Park",
      startDate: addDays(new Date(), 30),
      endDate: addDays(new Date(), 35),
      itemCount: 35,
      memberCount: 12,
      progress: 75,
      status: "active"
    },
    {
      id: 2,
      name: "Team Building Weekend",
      description: "Team building activities and workshops",
      location: "Lakeside Conference Center",
      startDate: addDays(new Date(), 14),
      endDate: addDays(new Date(), 16),
      itemCount: 22,
      memberCount: 8,
      progress: 40,
      status: "active"
    },
    {
      id: 3,
      name: "Product Launch Event",
      description: "Launch party for our new product line",
      location: "Downtown Convention Center",
      startDate: addDays(new Date(), 45),
      endDate: addDays(new Date(), 46),
      itemCount: 48,
      memberCount: 15,
      progress: 25,
      status: "active"
    },
    {
      id: 4,
      name: "Spring Skiing Trip",
      description: "Annual skiing trip to the mountains",
      location: "Alpine Resort",
      startDate: addDays(new Date(), -90),
      endDate: addDays(new Date(), -85),
      itemCount: 40,
      memberCount: 10,
      progress: 100,
      status: "completed"
    },
    {
      id: 5,
      name: "Fall Hiking Expedition",
      description: "Team hiking trip to explore fall foliage",
      location: "National Forest",
      startDate: addDays(new Date(), -45),
      endDate: addDays(new Date(), -43),
      itemCount: 30,
      memberCount: 8,
      progress: 100,
      status: "completed"
    }
  ];
  
  // Filter events based on search term
  const filteredEvents = events.filter(event => 
    event.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.location.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Separate active and completed events
  const activeEvents = filteredEvents.filter(event => event.status === "active");
  const completedEvents = filteredEvents.filter(event => event.status === "completed");
  
  // Format date range
  const formatDateRange = (startDate: Date, endDate: Date) => {
    return `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d, yyyy')}`;
  };
  
  // Get progress bar color
  const getProgressColor = (progress: number) => {
    if (progress < 30) return "bg-yellow-400";
    if (progress < 70) return "bg-blue-400";
    return "bg-green-400";
  };
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Events</h1>
            <p className="text-gray-600 mt-1">Manage all your trips and group outings</p>
          </div>
          <Button onClick={() => setIsCreateEventOpen(true)}>
            <CalendarPlus className="h-4 w-4 mr-2" />
            Create Event
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <CalendarDays className="h-5 w-5 mr-2 text-primary-500" />
                Total Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{events.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-blue-500" />
                Active Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-500">{activeEvents.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-green-500" />
                Completed Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-500">{completedEvents.length}</div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Event Management</CardTitle>
            <CardDescription>
              Create, view and manage all your events
            </CardDescription>
            <div className="pt-4">
              <Input
                type="search"
                placeholder="Search events by name, description, or location..."
                className="max-w-md"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="active">
              <TabsList className="mb-4">
                <TabsTrigger value="active">Active Events</TabsTrigger>
                <TabsTrigger value="completed">Completed Events</TabsTrigger>
                <TabsTrigger value="all">All Events</TabsTrigger>
              </TabsList>
              
              <TabsContent value="active">
                <div className="grid grid-cols-1 gap-4">
                  {activeEvents.map(event => (
                    <Card key={event.id} className="overflow-hidden">
                      <div className="flex flex-col md:flex-row">
                        <div className="p-6 flex-1">
                          <h3 className="text-lg font-semibold">{event.name}</h3>
                          <p className="text-gray-500 mt-1">{event.description}</p>
                          
                          <div className="mt-4 grid grid-cols-2 gap-4">
                            <div className="flex items-center text-sm text-gray-600">
                              <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.location}</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Clock className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{formatDateRange(event.startDate, event.endDate)}</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <User className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.memberCount} members</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Package className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.itemCount} items</span>
                            </div>
                          </div>
                          
                          <div className="mt-4">
                            <div className="flex justify-between mb-1">
                              <span className="text-sm font-medium text-gray-700">Progress</span>
                              <span className="text-sm font-medium text-gray-700">{event.progress}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className={`${getProgressColor(event.progress)} h-2 rounded-full`} 
                                style={{ width: `${event.progress}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-gray-50 p-6 flex flex-col justify-center items-center md:w-48">
                          <div className="text-center">
                            <div className="text-3xl font-bold">{Math.ceil((event.startDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}</div>
                            <div className="text-sm text-gray-500">days left</div>
                          </div>
                          <div className="flex flex-col w-full gap-2">
                            <Button 
                              className="mt-4 w-full" 
                              variant="outline"
                              onClick={() => handleViewDetails(event)}
                            >
                              View Details
                              <ChevronRight className="h-4 w-4 ml-2" />
                            </Button>
                            <Button 
                              className="w-full" 
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedEvent(event);
                                setIsShareDialogOpen(true);
                              }}
                            >
                              <Share2 className="h-4 w-4 mr-2" />
                              Share
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="completed">
                <div className="grid grid-cols-1 gap-4">
                  {completedEvents.map(event => (
                    <Card key={event.id} className="overflow-hidden opacity-80">
                      <div className="flex flex-col md:flex-row">
                        <div className="p-6 flex-1">
                          <h3 className="text-lg font-semibold">{event.name}</h3>
                          <p className="text-gray-500 mt-1">{event.description}</p>
                          
                          <div className="mt-4 grid grid-cols-2 gap-4">
                            <div className="flex items-center text-sm text-gray-600">
                              <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.location}</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Clock className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{formatDateRange(event.startDate, event.endDate)}</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <User className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.memberCount} members</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Package className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.itemCount} items</span>
                            </div>
                          </div>
                          
                          <div className="mt-4">
                            <div className="flex justify-between mb-1">
                              <span className="text-sm font-medium text-gray-700">Progress</span>
                              <span className="text-sm font-medium text-gray-700">{event.progress}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-green-400 h-2 rounded-full" 
                                style={{ width: `${event.progress}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-gray-50 p-6 flex flex-col justify-center items-center md:w-48">
                          <div className="text-center">
                            <div className="text-sm font-semibold text-green-600">Completed</div>
                            <div className="text-sm text-gray-500">{format(event.endDate, 'MMM d, yyyy')}</div>
                          </div>
                          <div className="flex flex-col w-full gap-2">
                            <Button 
                              className="mt-4 w-full" 
                              variant="outline"
                              onClick={() => handleViewDetails(event)}
                            >
                              View Details
                              <ChevronRight className="h-4 w-4 ml-2" />
                            </Button>
                            <Button 
                              className="w-full" 
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedEvent(event);
                                setIsShareDialogOpen(true);
                              }}
                            >
                              <Share2 className="h-4 w-4 mr-2" />
                              Share
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="all">
                <div className="grid grid-cols-1 gap-4">
                  {filteredEvents.map(event => (
                    <Card key={event.id} className={`overflow-hidden ${event.status === 'completed' ? 'opacity-80' : ''}`}>
                      <div className="flex flex-col md:flex-row">
                        <div className="p-6 flex-1">
                          <h3 className="text-lg font-semibold">{event.name}</h3>
                          <p className="text-gray-500 mt-1">{event.description}</p>
                          
                          <div className="mt-4 grid grid-cols-2 gap-4">
                            <div className="flex items-center text-sm text-gray-600">
                              <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.location}</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Clock className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{formatDateRange(event.startDate, event.endDate)}</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <User className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.memberCount} members</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Package className="h-4 w-4 mr-2 text-gray-400" />
                              <span>{event.itemCount} items</span>
                            </div>
                          </div>
                          
                          <div className="mt-4">
                            <div className="flex justify-between mb-1">
                              <span className="text-sm font-medium text-gray-700">Progress</span>
                              <span className="text-sm font-medium text-gray-700">{event.progress}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className={`${getProgressColor(event.progress)} h-2 rounded-full`} 
                                style={{ width: `${event.progress}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-gray-50 p-6 flex flex-col justify-center items-center md:w-48">
                          {event.status === 'active' ? (
                            <div className="text-center">
                              <div className="text-3xl font-bold">{Math.ceil((event.startDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}</div>
                              <div className="text-sm text-gray-500">days left</div>
                            </div>
                          ) : (
                            <div className="text-center">
                              <div className="text-sm font-semibold text-green-600">Completed</div>
                              <div className="text-sm text-gray-500">{format(event.endDate, 'MMM d, yyyy')}</div>
                            </div>
                          )}
                          
                          <Button className="mt-4 w-full" variant="outline">
                            View Details
                            <ChevronRight className="h-4 w-4 ml-2" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}