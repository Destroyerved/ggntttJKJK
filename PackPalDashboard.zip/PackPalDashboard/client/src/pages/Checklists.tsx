import DashboardLayout from "@/components/dashboard/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckSquare, List, CheckCheck, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function Checklists() {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Mock items data
  const items = [
    {
      id: 1,
      name: "Tent (4-person)",
      category: "Shelter",
      status: "packed",
      assignedTo: "John Doe",
      dueDate: "2 days before event"
    },
    {
      id: 2,
      name: "Sleeping bags",
      category: "Shelter",
      status: "packed",
      assignedTo: "Jane Smith",
      dueDate: "2 days before event"
    },
    {
      id: 3,
      name: "Camping pillows",
      category: "Shelter",
      status: "to_pack",
      assignedTo: "Bob Williams",
      dueDate: "2 days before event"
    },
    {
      id: 4,
      name: "Portable camp stove",
      category: "Food & Cooking",
      status: "to_pack",
      assignedTo: "Sarah Parker",
      dueDate: "1 day before event"
    },
    {
      id: 5,
      name: "Cooler",
      category: "Food & Cooking",
      status: "to_pack",
      assignedTo: "John Doe",
      dueDate: "1 day before event"
    },
    {
      id: 6,
      name: "Rain jackets",
      category: "Clothing",
      status: "to_pack",
      assignedTo: "Unassigned",
      dueDate: "3 days before event"
    },
    {
      id: 7,
      name: "Headlamps",
      category: "Tools & Equipment",
      status: "packed",
      assignedTo: "Jane Smith",
      dueDate: "3 days before event"
    },
    {
      id: 8,
      name: "Multi-tool",
      category: "Tools & Equipment",
      status: "delivered",
      assignedTo: "Bob Williams",
      dueDate: "4 days before event"
    },
    {
      id: 9,
      name: "First aid kit",
      category: "First Aid & Safety",
      status: "packed",
      assignedTo: "Sarah Parker",
      dueDate: "4 days before event"
    },
    {
      id: 10,
      name: "Sunscreen",
      category: "First Aid & Safety",
      status: "to_pack",
      assignedTo: "Unassigned",
      dueDate: "1 day before event"
    }
  ];
  
  // Filter items based on search term
  const filteredItems = items.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.assignedTo.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Get status badge styling
  const getStatusBadge = (status: string) => {
    switch(status) {
      case "to_pack":
        return "bg-yellow-100 text-yellow-800";
      case "packed":
        return "bg-green-100 text-green-800";
      case "delivered":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Item Checklists</h1>
            <p className="text-gray-600 mt-1">Manage all your items for Summer Camping Trip</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button size="sm">
              <CheckSquare className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <List className="h-5 w-5 mr-2 text-yellow-500" />
                To Pack
              </CardTitle>
              <CardDescription>Items that need to be packed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-500">
                {items.filter(item => item.status === "to_pack").length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <CheckSquare className="h-5 w-5 mr-2 text-green-500" />
                Packed
              </CardTitle>
              <CardDescription>Items that have been packed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-500">
                {items.filter(item => item.status === "packed").length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <CheckCheck className="h-5 w-5 mr-2 text-blue-500" />
                Delivered
              </CardTitle>
              <CardDescription>Items delivered to destination</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-500">
                {items.filter(item => item.status === "delivered").length}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Items</CardTitle>
            <CardDescription>
              View and manage all items for this event
            </CardDescription>
            <div className="pt-4">
              <Input
                type="search"
                placeholder="Search items, categories, or assignees..."
                className="max-w-md"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                  <tr>
                    <th className="px-6 py-3">Item Name</th>
                    <th className="px-6 py-3">Category</th>
                    <th className="px-6 py-3">Status</th>
                    <th className="px-6 py-3">Assigned To</th>
                    <th className="px-6 py-3">Due Date</th>
                    <th className="px-6 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredItems.map(item => (
                    <tr key={item.id} className="bg-white border-b hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">{item.name}</td>
                      <td className="px-6 py-4">{item.category}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(item.status)}`}>
                          {item.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4">{item.assignedTo}</td>
                      <td className="px-6 py-4">{item.dueDate}</td>
                      <td className="px-6 py-4">
                        <Button variant="ghost" size="sm">Edit</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}