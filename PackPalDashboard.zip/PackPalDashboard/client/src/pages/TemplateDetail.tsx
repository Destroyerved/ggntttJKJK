import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation, useRoute, Link } from 'wouter';
import { format } from 'date-fns';
import { Loader2, ArrowLeft, CheckCircle, Package, Calendar, MapPin, PlusCircle, Share2, Copy, Mail } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';

// Define the types for our template data
interface Template {
  id: number;
  name: string;
  description: string | null;
  type: string;
  thumbnail: string;
  isPublic: boolean;
  createdBy: number;
  createdAt: string;
}

interface TemplateItem {
  id: number;
  name: string;
  description: string | null;
  templateId: number;
  templateCategoryId: number;
  quantity: number;
  notes: string | null;
}

interface TemplateCategory {
  id: number;
  name: string;
  templateId: number;
  items: TemplateItem[];
}

interface TemplateDetailData {
  template: Template;
  categories: TemplateCategory[];
}

// Create event form schema
const formSchema = z.object({
  name: z.string().min(3, { message: "Event name is required and must be at least 3 characters" }),
  description: z.string().optional(),
  location: z.string().optional(),
  startDate: z.date({ required_error: "Start date is required" }),
  endDate: z.date().optional(),
  createdBy: z.number().default(1) // Default to current user ID
});

export default function TemplateDetail() {
  const [, params] = useRoute('/templates/:id');
  const templateId = params?.id ? parseInt(params.id) : null;
  const [, navigate] = useLocation();
  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false);
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [shareOption, setShareOption] = useState("link");
  const [emailAddresses, setEmailAddresses] = useState("");
  const [emailMessage, setEmailMessage] = useState("Check out this template I found on PackPal!");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      description: '',
      location: '',
      createdBy: 1,
    },
  });

  // Fetch template details
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/templates', templateId],
    enabled: templateId !== null,
    retry: false,
    refetchOnWindowFocus: false,
  });

  // Create event mutation
  const createEventMutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      if (!templateId) throw new Error("Template ID is missing");
      
      const response = await fetch(`/api/templates/${templateId}/create-event`, {
        method: 'POST',
        body: JSON.stringify(values),
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!response.ok) {
        throw new Error('Failed to create event');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      toast({
        title: "Event created!",
        description: "Your event has been successfully created from this template.",
      });
      setIsCreateEventOpen(false);
      navigate(`/dashboard?event=${data.id}`);
    },
    onError: (error) => {
      toast({
        title: "Failed to create event",
        description: "There was a problem creating your event. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Form submission handler
  function onSubmit(values: z.infer<typeof formSchema>) {
    createEventMutation.mutate(values);
  }
  
  const handleShare = () => {
    if (shareOption === "link") {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Template link copied to clipboard. You can now share it with anyone.",
      });
    } else {
      toast({
        title: "Shared Successfully",
        description: `Template details shared via ${shareOption}.`,
      });
    }
    setIsShareDialogOpen(false);
  };

  const templateData = data as TemplateDetailData;

  // Format the type name for display
  const formatTypeName = (type: string) => {
    return type.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-lg">Loading template details...</span>
      </div>
    );
  }

  if (error || !templateData) {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <p className="text-lg text-red-600">Failed to load template details</p>
        <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
          Try Again
        </Button>
      </div>
    );
  }

  const { template, categories } = templateData;
  const totalItems = categories.reduce((sum, category) => sum + category.items.length, 0);

  return (
    <div className="container mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <Link href="/templates">
            <Button variant="outline" size="sm" className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Templates
            </Button>
          </Link>
          <Badge variant="outline" className="text-sm">
            {formatTypeName(template.type)}
          </Badge>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Template Image */}
          <div 
            className="w-full md:w-1/3 h-64 md:h-auto rounded-lg bg-cover bg-center" 
            style={{ backgroundImage: `url(${template.thumbnail})` }}
          />
          
          {/* Template Info */}
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2">{template.name}</h1>
            <p className="text-muted-foreground mb-4">
              {template.description}
            </p>
            
            <div className="flex flex-wrap gap-4 mb-6">
              <div className="bg-muted rounded-md px-4 py-2 flex items-center">
                <Package className="h-5 w-5 mr-2 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">{totalItems} Items</div>
                  <div className="text-xs text-muted-foreground">{categories.length} Categories</div>
                </div>
              </div>
              
              <div className="bg-muted rounded-md px-4 py-2 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Created</div>
                  <div className="text-xs text-muted-foreground">
                    {format(new Date(template.createdAt), 'MMM d, yyyy')}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <Button 
                className="w-full md:w-auto"
                onClick={() => setIsCreateEventOpen(true)}
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Create Event from Template
              </Button>
              <Button 
                className="w-full md:w-auto"
                variant="outline"
                onClick={() => setIsShareDialogOpen(true)}
              >
                <Share2 className="mr-2 h-4 w-4" />
                Share Template
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <Separator className="my-8" />
      
      {/* Template content */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Template Contents</h2>
        
        {categories.length === 0 ? (
          <div className="text-center py-12 border rounded-lg">
            <p className="text-muted-foreground">This template has no content yet</p>
          </div>
        ) : (
          <div className="space-y-8">
            {categories.map((category) => (
              <div key={category.id} className="border rounded-lg overflow-hidden">
                <div className="bg-muted px-4 py-3">
                  <h3 className="font-medium">{category.name}</h3>
                </div>
                
                <div className="divide-y">
                  {category.items.map((item) => (
                    <div key={item.id} className="p-4 flex items-start">
                      <CheckCircle className="h-5 w-5 mr-3 text-muted-foreground flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="font-medium">{item.name}</div>
                        {item.description && (
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        )}
                        {item.quantity > 1 && (
                          <span className="text-xs bg-muted px-2 py-1 rounded mt-1 inline-block">
                            Qty: {item.quantity}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Create Event Dialog */}
      <Dialog open={isCreateEventOpen} onOpenChange={setIsCreateEventOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create Event from Template</DialogTitle>
            <DialogDescription>
              Enter details for your new event based on "{template.name}"
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Event Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter event name" 
                        {...field} 
                        defaultValue={template.name}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter event description" 
                        className="resize-none" 
                        {...field} 
                        value={field.value || ''}
                        defaultValue={template.description || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter event location" 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date</FormLabel>
                      <FormControl>
                        <div className="border rounded-md p-2">
                          <CalendarComponent
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date (Optional)</FormLabel>
                      <FormControl>
                        <div className="border rounded-md p-2">
                          <CalendarComponent
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter className="mt-6">
                <Button 
                  variant="outline" 
                  type="button" 
                  onClick={() => setIsCreateEventOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createEventMutation.isPending}
                >
                  {createEventMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Create Event
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Share Dialog */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Template</DialogTitle>
            <DialogDescription>
              Share this template with your team or others.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="font-medium">Share via</div>
              <div className="grid grid-cols-3 gap-2">
                <Button 
                  variant={shareOption === "link" ? "default" : "outline"} 
                  onClick={() => setShareOption("link")}
                  className="w-full justify-start"
                >
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Link
                </Button>
                <Button 
                  variant={shareOption === "email" ? "default" : "outline"} 
                  onClick={() => setShareOption("email")}
                  className="w-full justify-start"
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Email
                </Button>
                <Button 
                  variant={shareOption === "message" ? "default" : "outline"} 
                  onClick={() => setShareOption("message")}
                  className="w-full justify-start"
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Message
                </Button>
              </div>
            </div>
            
            {shareOption === "email" && (
              <div className="space-y-2">
                <label htmlFor="email" className="font-medium">Email Addresses</label>
                <Input 
                  id="email" 
                  placeholder="Enter email addresses separated by commas" 
                  value={emailAddresses}
                  onChange={(e) => setEmailAddresses(e.target.value)}
                />
                <label htmlFor="message" className="font-medium">Message</label>
                <Textarea 
                  id="message" 
                  placeholder="Add a personal message" 
                  value={emailMessage}
                  onChange={(e) => setEmailMessage(e.target.value)}
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsShareDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleShare}>Share</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}