import { useQuery } from "@tanstack/react-query";

export default function useDashboardData(eventId: number) {
  return useQuery({
    queryKey: [`/api/dashboard/${eventId}`],
    // The queryFn is already set up in queryClient.ts as a default
  });
}
