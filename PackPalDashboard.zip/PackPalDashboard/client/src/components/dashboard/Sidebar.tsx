import { useState } from "react";
import { useLocation, Link } from "wouter";
import { 
  Home, PackageCheck, Users, Calendar, FileText, 
  BarChart2, Settings, Box
} from "lucide-react";

interface SidebarProps {
  currentUser: {
    displayName: string;
    role: string;
    avatarUrl: string;
  };
}

export default function Sidebar({ currentUser }: SidebarProps) {
  const [location] = useLocation();
  
  // Get role color based on user role
  const getRoleColor = (role: string) => {
    switch (role.toLowerCase()) {
      case "owner":
        return "bg-primary-100 text-primary-800";
      case "admin":
        return "bg-green-100 text-green-800";
      case "member":
        return "bg-blue-100 text-blue-800";
      case "viewer":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 border-r border-gray-200">
        <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto bg-white">
          <div className="flex items-center flex-shrink-0 px-4">
            <div className="flex items-center">
              <Box className="h-8 w-8 text-primary-600" />
              <h1 className="text-xl font-bold text-primary-700 ml-2">PackPal</h1>
            </div>
          </div>
          <div className="mt-5 flex-grow flex flex-col">
            <nav className="flex-1 px-2 space-y-1">
              <Link href="/">
                <div className={`flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === "/" 
                    ? "bg-primary-50 text-primary-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}>
                  <Home className={`mr-3 h-5 w-5 ${
                    location === "/" ? "text-primary-500" : "text-gray-400"
                  }`} />
                  Dashboard
                </div>
              </Link>
              <Link href="/checklists">
                <div className={`flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === "/checklists" 
                    ? "bg-primary-50 text-primary-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}>
                  <PackageCheck className={`mr-3 h-5 w-5 ${
                    location === "/checklists" ? "text-primary-500" : "text-gray-400"
                  }`} />
                  Checklists
                </div>
              </Link>
              <Link href="/team">
                <div className={`flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === "/team" 
                    ? "bg-primary-50 text-primary-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}>
                  <Users className={`mr-3 h-5 w-5 ${
                    location === "/team" ? "text-primary-500" : "text-gray-400"
                  }`} />
                  Team
                </div>
              </Link>
              <Link href="/events">
                <div className={`flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === "/events" 
                    ? "bg-primary-50 text-primary-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}>
                  <Calendar className={`mr-3 h-5 w-5 ${
                    location === "/events" ? "text-primary-500" : "text-gray-400"
                  }`} />
                  Events
                </div>
              </Link>
              <Link href="/templates">
                <div className={`flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === "/templates" 
                    ? "bg-primary-50 text-primary-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}>
                  <FileText className={`mr-3 h-5 w-5 ${
                    location === "/templates" ? "text-primary-500" : "text-gray-400"
                  }`} />
                  Templates
                </div>
              </Link>
              <Link href="/analytics">
                <div className={`flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === "/analytics" 
                    ? "bg-primary-50 text-primary-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}>
                  <BarChart2 className={`mr-3 h-5 w-5 ${
                    location === "/analytics" ? "text-primary-500" : "text-gray-400"
                  }`} />
                  Analytics
                </div>
              </Link>
              <Link href="/settings">
                <div className={`flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === "/settings" 
                    ? "bg-primary-50 text-primary-700" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}>
                  <Settings className={`mr-3 h-5 w-5 ${
                    location === "/settings" ? "text-primary-500" : "text-gray-400"
                  }`} />
                  Settings
                </div>
              </Link>
            </nav>
          </div>
          
          {/* User Profile Section */}
          <div className="flex items-center p-4 border-t border-gray-200">
            <img 
              className="h-8 w-8 rounded-full"
              src={currentUser.avatarUrl}
              alt={`${currentUser.displayName}'s avatar`}
            />
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-700">{currentUser.displayName}</p>
              <div className="flex items-center">
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getRoleColor(currentUser.role)}`}>
                  {currentUser.role}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
