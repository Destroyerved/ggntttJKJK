import { Box, ClipboardList, CheckSquare, CheckCircle } from "lucide-react";

interface StatsItem {
  id: string;
  label: string;
  value: number;
  icon: React.ReactNode;
  color: string;
}

interface StatsOverviewProps {
  stats: {
    totalItems: number;
    toPackItems: number;
    packedItems: number;
    deliveredItems: number;
  };
}

export default function StatsOverview({ stats }: StatsOverviewProps) {
  const statsItems: StatsItem[] = [
    {
      id: "total",
      label: "Total Items",
      value: stats.totalItems,
      icon: <Box className="text-primary-600 text-xl" />,
      color: "bg-primary-100"
    },
    {
      id: "to-pack",
      label: "To Pack",
      value: stats.toPackItems,
      icon: <ClipboardList className="text-yellow-600 text-xl" />,
      color: "bg-yellow-100"
    },
    {
      id: "packed",
      label: "Packed",
      value: stats.packedItems,
      icon: <CheckSquare className="text-blue-600 text-xl" />,
      color: "bg-blue-100"
    },
    {
      id: "delivered",
      label: "Delivered",
      value: stats.deliveredItems,
      icon: <CheckCircle className="text-green-600 text-xl" />,
      color: "bg-green-100"
    }
  ];

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {statsItems.map((item) => (
        <div key={item.id} className="bg-white overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex items-center">
              <div className={`flex-shrink-0 ${item.color} rounded-md p-3`}>
                {item.icon}
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">{item.label}</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{item.value}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
