import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import TopNavigation from "./TopNavigation";

interface DashboardLayoutProps {
  children: ReactNode;
  currentUser?: {
    id?: number;
    displayName: string;
    role: string;
    avatarUrl: string;
  };
}

// Default mock user if none is provided
const defaultUser = {
  displayName: "John Doe",
  role: "Owner",
  avatarUrl: "https://ui-avatars.com/api/?name=John+Doe&background=0D8ABC&color=fff"
};

export default function DashboardLayout({ children, currentUser = defaultUser }: DashboardLayoutProps) {
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar currentUser={currentUser} />
      
      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Top Navigation */}
        <TopNavigation currentUser={currentUser} />
        
        {/* Main Content Area */}
        <main className="flex-1 relative overflow-y-auto focus:outline-none bg-gray-50">
          <div className="py-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
