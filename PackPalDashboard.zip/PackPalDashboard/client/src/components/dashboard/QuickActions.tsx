import { FileOutput, Mail, Share2, FileSpreadsheet, FileText, PlusCircle, Check, X, Copy } from "lucide-react";
import { Link, useLocation } from "wouter";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function QuickActions() {
  const [location] = useLocation();
  const { toast } = useToast();
  
  // Dialog states
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [emailDialogOpen, setEmailDialogOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [createEventDialogOpen, setCreateEventDialogOpen] = useState(false);
  
  const [exportFormat, setExportFormat] = useState("pdf");
  const [emailAddresses, setEmailAddresses] = useState("");
  const [emailMessage, setEmailMessage] = useState("Here's the packing list for our upcoming event!");
  const [shareOption, setShareOption] = useState("link");
  
  const actions = [
    {
      id: "browse-templates",
      icon: <FileText className="text-primary-600 text-xl mb-2" />,
      label: "Browse Templates",
      link: "/templates"
    },
    {
      id: "export-pdf",
      icon: <FileOutput className="text-primary-600 text-xl mb-2" />,
      label: "Export PDF",
      onClick: () => setExportDialogOpen(true)
    },
    {
      id: "share",
      icon: <Share2 className="text-primary-600 text-xl mb-2" />,
      label: "Share",
      onClick: () => setShareDialogOpen(true)
    },
    {
      id: "create-event",
      icon: <PlusCircle className="text-primary-600 text-xl mb-2" />,
      label: "Create Event",
      onClick: () => setCreateEventDialogOpen(true)
    }
  ];

  const handleActionClick = (action: any) => {
    if (action.onClick) {
      action.onClick();
    } else {
      console.log(`Action clicked: ${action.id}`);
    }
  };
  
  const handleExport = () => {
    toast({
      title: "Export Started",
      description: `Exporting as ${exportFormat.toUpperCase()}. Your download will begin shortly.`,
    });
    setExportDialogOpen(false);
  };
  
  const handleShare = () => {
    if (shareOption === "link") {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Link copied to clipboard. You can now share it with anyone.",
      });
    } else {
      toast({
        title: "Shared Successfully",
        description: `Event details shared via ${shareOption}.`,
      });
    }
    setShareDialogOpen(false);
  };
  
  const handleCreateEvent = () => {
    toast({
      title: "Event Created",
      description: "Your new event has been created successfully.",
    });
    setCreateEventDialogOpen(false);
  };

  return (
    <>
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
            {actions.map((action) => (
              action.link ? (
                <Link key={action.id} href={action.link}>
                  <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer">
                    {action.icon}
                    <span className="text-sm text-gray-700">{action.label}</span>
                  </div>
                </Link>
              ) : (
                <button
                  key={action.id}
                  className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100"
                  onClick={() => handleActionClick(action)}
                >
                  {action.icon}
                  <span className="text-sm text-gray-700">{action.label}</span>
                </button>
              )
            ))}
          </div>
        </div>
      </div>
      
      {/* Export Dialog */}
      <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Export Options</DialogTitle>
            <DialogDescription>
              Choose a format to export your packing list.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="font-medium">Export Format</div>
              <div className="grid grid-cols-3 gap-2">
                <Button 
                  variant={exportFormat === "pdf" ? "default" : "outline"} 
                  onClick={() => setExportFormat("pdf")}
                  className="w-full justify-start"
                >
                  <FileOutput className="mr-2 h-4 w-4" />
                  PDF
                </Button>
                <Button 
                  variant={exportFormat === "excel" ? "default" : "outline"} 
                  onClick={() => setExportFormat("excel")}
                  className="w-full justify-start"
                >
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Excel
                </Button>
                <Button 
                  variant={exportFormat === "csv" ? "default" : "outline"} 
                  onClick={() => setExportFormat("csv")}
                  className="w-full justify-start"
                >
                  <FileText className="mr-2 h-4 w-4" />
                  CSV
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <div className="font-medium">Include</div>
              <div className="flex flex-col space-y-2">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="include-items" defaultChecked />
                  <label htmlFor="include-items">All Items</label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="include-details" defaultChecked />
                  <label htmlFor="include-details">Item Details</label>
                </div>
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="include-assignments" defaultChecked />
                  <label htmlFor="include-assignments">Assignments</label>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setExportDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleExport}>Export</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Share Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share</DialogTitle>
            <DialogDescription>
              Share your event details with others.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="font-medium">Share via</div>
              <div className="grid grid-cols-3 gap-2">
                <Button 
                  variant={shareOption === "link" ? "default" : "outline"} 
                  onClick={() => setShareOption("link")}
                  className="w-full justify-start"
                >
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Link
                </Button>
                <Button 
                  variant={shareOption === "email" ? "default" : "outline"} 
                  onClick={() => setShareOption("email")}
                  className="w-full justify-start"
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Email
                </Button>
                <Button 
                  variant={shareOption === "message" ? "default" : "outline"} 
                  onClick={() => setShareOption("message")}
                  className="w-full justify-start"
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Message
                </Button>
              </div>
            </div>
            
            {shareOption === "email" && (
              <div className="space-y-2">
                <label htmlFor="email" className="font-medium">Email Addresses</label>
                <Input 
                  id="email" 
                  placeholder="Enter email addresses separated by commas" 
                  value={emailAddresses}
                  onChange={(e) => setEmailAddresses(e.target.value)}
                />
                <label htmlFor="message" className="font-medium">Message</label>
                <Textarea 
                  id="message" 
                  placeholder="Add a personal message" 
                  value={emailMessage}
                  onChange={(e) => setEmailMessage(e.target.value)}
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleShare}>Share</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Create Event Dialog */}
      <Dialog open={createEventDialogOpen} onOpenChange={setCreateEventDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Event</DialogTitle>
            <DialogDescription>
              Start a new event or use a template.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <label htmlFor="event-name" className="font-medium">Event Name</label>
              <Input id="event-name" placeholder="Enter event name" />
            </div>
            <div className="space-y-2">
              <label htmlFor="event-date" className="font-medium">Event Date</label>
              <Input id="event-date" type="date" />
            </div>
            <div className="space-y-2">
              <label htmlFor="event-template" className="font-medium">Template</label>
              <select id="event-template" className="w-full p-2 border rounded">
                <option value="">Choose a template (optional)</option>
                <option value="1">Camping Template</option>
                <option value="2">Vacation Template</option>
                <option value="3">Party Template</option>
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateEventDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateEvent}>Create Event</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
