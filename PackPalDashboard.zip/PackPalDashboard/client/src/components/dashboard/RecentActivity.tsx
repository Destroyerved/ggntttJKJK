import { Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ActivityUser {
  id: number;
  displayName: string;
}

interface Activity {
  id: number;
  action: string;
  createdAt: string;
  user?: ActivityUser;
  details: any;
}

interface RecentActivityProps {
  activities: Activity[];
}

export default function RecentActivity({ activities }: RecentActivityProps) {
  // Format activity message based on action type and details
  const formatActivityMessage = (activity: Activity) => {
    if (!activity.user && activity.action === "system") {
      return (
        <>
          <p className="font-medium text-primary-600 truncate">System</p>
          <p className="ml-1 flex-shrink-0 font-normal text-gray-500">
            {activity.details.message}
          </p>
        </>
      );
    }
    
    if (!activity.user) return null;
    
    switch (activity.action) {
      case "created":
        if (activity.details.event) {
          return (
            <>
              <p className="font-medium text-primary-600 truncate">{activity.user.displayName}</p>
              <p className="ml-1 flex-shrink-0 font-normal text-gray-500">
                created the "{activity.details.event}" event
              </p>
            </>
          );
        }
        
        return (
          <>
            <p className="font-medium text-primary-600 truncate">{activity.user.displayName}</p>
            <p className="ml-1 flex-shrink-0 font-normal text-gray-500">
              added "{activity.details.itemName}"
            </p>
          </>
        );
      
      case "status_changed":
        return (
          <>
            <p className="font-medium text-primary-600 truncate">{activity.user.displayName}</p>
            <p className="ml-1 flex-shrink-0 font-normal text-gray-500">
              marked item as {activity.details.newStatus}
            </p>
          </>
        );
        
      default:
        return (
          <>
            <p className="font-medium text-primary-600 truncate">{activity.user.displayName}</p>
            <p className="ml-1 flex-shrink-0 font-normal text-gray-500">
              performed an action
            </p>
          </>
        );
    }
  };
  
  // Format relative time (e.g., "10 minutes ago")
  const formatTime = (dateStr: string) => {
    try {
      return formatDistanceToNow(new Date(dateStr), { addSuffix: true });
    } catch (error) {
      return "recently";
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Recent Activity</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Latest updates from your team</p>
      </div>
      <div className="border-t border-gray-200">
        <ul className="divide-y divide-gray-200">
          {activities.map((activity) => (
            <li key={activity.id} className="px-4 py-4 sm:px-6">
              <div className="flex items-center">
                <div className="min-w-0 flex-1 sm:flex sm:items-center sm:justify-between">
                  <div>
                    <div className="flex text-sm">
                      {formatActivityMessage(activity)}
                    </div>
                    <div className="mt-2 flex">
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        <p>{formatTime(activity.createdAt)}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
        
        <div className="flex justify-center p-4 border-t border-gray-200">
          <button className="text-sm font-medium text-primary-600 hover:text-primary-500">
            View all activity
          </button>
        </div>
      </div>
    </div>
  );
}
