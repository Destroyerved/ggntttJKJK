import { Check, Clock, Mountain, Home } from "lucide-react";

interface Milestone {
  id: number;
  name: string;
  date: string;
  completed: boolean;
}

interface EventTimelineProps {
  timeline: {
    daysRemaining: number;
    progress: number;
    milestones: Milestone[];
    nextMilestone?: Milestone;
  };
}

export default function EventTimeline({ timeline }: EventTimelineProps) {
  // Format date to "MMM D" (e.g., "Jul 20")
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(date);
  };

  // Get milestone icon based on name
  const getMilestoneIcon = (name: string, completed: boolean) => {
    if (completed) {
      return <Check className="text-xs" />;
    }
    
    switch (name.toLowerCase()) {
      case "departure":
        return <Mountain className="text-xs text-gray-400" />;
      case "return":
        return <Home className="text-xs text-gray-400" />;
      default:
        return <Clock className="text-xs" />;
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
        <div>
          <h3 className="text-lg leading-6 font-medium text-gray-900">Event Timeline</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Next milestone: {timeline.nextMilestone ? `${timeline.nextMilestone.name} - ${new Date(timeline.nextMilestone.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}` : 'None'}
          </p>
        </div>
        <div className="text-3xl font-bold text-primary-600">
          {timeline.daysRemaining} <span className="text-sm font-normal text-gray-500">days left</span>
        </div>
      </div>
      <div className="border-t border-gray-200">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="text-sm font-medium text-gray-500">Progress</div>
            <div className="text-sm font-medium text-primary-600">{timeline.progress}%</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-primary-600 h-2.5 rounded-full" 
              style={{ width: `${timeline.progress}%` }}
            ></div>
          </div>
          
          <div className="mt-6 relative">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            
            {/* Timeline dates */}
            <div className="relative flex justify-between">
              {timeline.milestones.map((milestone) => (
                <div key={milestone.id} className="flex flex-col items-center">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                    milestone.completed 
                      ? "bg-green-500 text-white" 
                      : milestone.id === timeline.nextMilestone?.id
                        ? "bg-primary-600 text-white relative"
                        : "bg-gray-200"
                  }`}>
                    {getMilestoneIcon(milestone.name, milestone.completed)}
                    {milestone.id === timeline.nextMilestone?.id && (
                      <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white"></span>
                    )}
                  </div>
                  <span className="mt-2 text-xs text-gray-500">{formatDate(milestone.date)}</span>
                  <span className="mt-1 text-xs font-medium">{milestone.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
