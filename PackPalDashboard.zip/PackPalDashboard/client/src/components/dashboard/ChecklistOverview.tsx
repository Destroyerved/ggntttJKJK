import { Progress } from "@/components/ui/progress";

interface CategoryProgress {
  id: number;
  name: string;
  total: number;
  completed: number;
  percentage: number;
}

interface ChecklistOverviewProps {
  categoryProgress: CategoryProgress[];
}

export default function ChecklistOverview({ categoryProgress }: ChecklistOverviewProps) {
  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Packing Progress</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">By category</p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        {categoryProgress.map((category) => (
          <div key={category.id} className="mb-4 last:mb-0">
            <div className="flex justify-between items-center mb-1">
              <div className="text-sm font-medium text-gray-700">{category.name}</div>
              <div className="text-sm font-medium text-primary-600">
                {category.completed}/{category.total}
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`${category.percentage === 100 ? 'bg-green-500' : 'bg-primary-600'} h-2 rounded-full`} 
                style={{ width: `${category.percentage}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
