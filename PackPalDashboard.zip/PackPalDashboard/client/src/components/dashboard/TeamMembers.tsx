import { Button } from "@/components/ui/button";

interface TeamMember {
  id: number;
  user: {
    id: number;
    displayName: string;
    avatarUrl: string;
    role: string;
  };
  itemCount: number;
}

interface TeamMembersProps {
  members: TeamMember[];
}

export default function TeamMembers({ members }: TeamMembersProps) {
  // Get role color based on user role
  const getRoleColor = (role: string) => {
    switch (role.toLowerCase()) {
      case "owner":
        return "bg-primary-100 text-primary-800";
      case "admin":
        return "bg-green-100 text-green-800";
      case "member":
        return "bg-blue-100 text-blue-800";
      case "viewer":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Team Members</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">{members.length} members</p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        <ul className="divide-y divide-gray-200">
          {members.slice(0, 4).map((member) => (
            <li key={member.id} className="py-3 flex justify-between items-center">
              <div className="flex items-center">
                <img 
                  className="h-8 w-8 rounded-full"
                  src={member.user.avatarUrl} 
                  alt={`${member.user.displayName}'s profile picture`}
                />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{member.user.displayName}</p>
                  <div className="flex items-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getRoleColor(member.user.role)}`}>
                      {member.user.role}
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-500">{member.itemCount} items</div>
            </li>
          ))}
        </ul>
        
        <Button 
          variant="outline" 
          className="mt-4 w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-primary-600 bg-white hover:bg-gray-50 focus:outline-none border-primary-300"
        >
          View All Members
        </Button>
      </div>
    </div>
  );
}
